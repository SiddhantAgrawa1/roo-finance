import React from 'react';

import Header from '../components/Header/Header';
import Breadcrumb from '../components/Breadcrumb/Breadcrumb';
import ProjectSingle from '../components/Project/Project';
import Cta from '../components/Cta/Cta';
import Footer from '../components/Footer/Footer';
import ModalSearch from '../components/Modal/ModalSearch';
import ModalMenu from '../components/Modal/ModalMenu';

const Project = () => {
        return (
            <div className="main">
                <Header />
                <Breadcrumb title="Project" subpage="Project" page={window.location.pathname.split('/')[2]} />
                <ProjectSingle />
                <Cta />
                <Footer />
                <ModalSearch />
                <ModalMenu />
            </div>
        );
}

export default Project;