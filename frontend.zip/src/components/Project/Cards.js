import React from "react";
import Counter from "./Counter";
import DateFormat from "./DateFormat";

function Cards({ data }) {
  return (
    <>
      {data.map((item, idx) => (
        <div
          key={`pd_${idx}`}
          className="col-12 col-md-6 col-lg-4 item explore-item"
          data-groups={item.group}
        >
          {console.log(item)}
          <div className="card project-card">
            <div className="media">
              <a href={"/project/" + item.Name_Of_Project.replace(/\s+/g, "-")}>
                {/* {console.log(item)} */}
                <img
                  className="card-img-top avatar-max-lg"
                  src={`${process.env.REACT_APP_API_URL}${item.imgUrl}`}
                  alt=""
                />
              </a>
              <div className="media-body ml-4">
                <a
                  href={"/project/" + item.Name_Of_Project.replace(/\s+/g, "-")}
                >
                  <h4 className="m-0">{item.Name_Of_Project}</h4>
                </a>
                {new Date(item.Date_of_Launch*1000) >= new Date() ? (
                  <div className="countdown-times">
                    <h6 className="my-2">Launching in:</h6>
                    <div className="countdown d-flex">
                      <Counter date={item.Date_of_Launch*1000} />
                    </div>
                  </div>
                ) : (
                  <div className="countdown-times">
                    <h6 className="my-2">Lauched at:</h6>
                    <div><DateFormat date={item.Date_of_Launch*1000}/></div>
                  </div>
                )}
              </div>
            </div>
            {/* Project Body */}
            <div className="card-body">
              <div className="items">
                {/* Single Item */}
                <div className="single-item">
                  <span>Total raise</span>
                  <span>
                    {item.Amount_of_supply * item.Price_of_collection
                      ? item.Amount_of_supply * item.Price_of_collection
                      : "--"}
                  </span>
                </div>
                {/* Single Item */}
                <div className="single-item">
                  <span>Value: </span>
                  <span>{item.value ? item.value : "--"}</span>
                </div>
                {/* Single Item */}
                {/* <div className="single-item">
                          <span>Verified</span>
                          <span> {item.allocation}</span>
                        </div> */}
              </div>
              <div className="progress-sale d-flex justify-content-between mt-3">
                <span>{item.Amount_of_supply ? item.Amount_of_supply: "--"} SUPPLY</span>
                <span>{item.Price_of_collection ? item.Price_of_collection/ 10**6  : "--"} CRO</span>
              </div>
            </div>
            {/* Project Footer */}
            <div className="project-footer d-flex align-items-center mt-4 mt-md-5">
              <a
                className={`btn btn-bordered-white btn-smaller`}
                onClick={() =>
                  (window.location.href = `/project/${item.Name_Of_Project.replace(/\s+/g,"-")}`)
                }
              >
                Mint
              </a>
              {/* Social Share */}
              <div className="social-share ml-auto">
                <ul className="d-flex list-unstyled">
                  {item.Twitter_Link ? (
                    <li>
                      <a href={item.Twitter_Link}>
                        <i className="fab fa-twitter" />
                      </a>
                    </li>
                  ) : null}
                  {item.Telegram_Link ? (
                    <li>
                      <a href={item.Telegram_Link}>
                        <i className="fab fa-telegram" />
                      </a>
                    </li>
                  ) : null}
                  {item.Website ? (
                    <li>
                      <a href={item.Website}>
                        <i className="fas fa-globe" />
                      </a>
                    </li>
                  ) : null}
                  {item.Discord_Link ? (
                    <li>
                      <a href={item.Discord_Link}>
                        <i className="fab fa-discord" />
                      </a>
                    </li>
                  ) : null}
                </ul>
              </div>
            </div>
            {/* Blockchain Icon */}
            <div className="blockchain-icon">
              <img src={item.blockchain} alt="" />
            </div>
          </div>
        </div>
      ))}
    </>
  );
}

export default Cards;
