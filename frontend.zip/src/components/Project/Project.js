import React, { Component } from "react";
import parse from "html-react-parser";
import { ethers } from "ethers";
import ERC20_ABI from "../ContractData/bsc.json";
import { toast } from "react-toastify";
import Counter from "./Counter";
import axios from "axios";
import { GetProvider, switchNetwork1 } from "../Service/WalletService";
import { Convert } from "./ConvertMintPrice";
import { ClipLoader } from "react-spinners";
import DateFormat from "./DateFormat";

class Project extends Component {
  state = {
    Data: null,
    url:
      `${process.env.REACT_APP_API_URL}project/` +
      window.location.pathname.split("/")[2].replace(/\s+/g, '-'),
    OpenLoader: true,
    mintLoader: false,
    refundLoader: false,
    token_id: false,
    count: 1,
    textCopied: 0,
    ref:
      window.location.pathname.split("/").length === 4
        ? window.location.pathname.split("/")[3]
        : "0x0000000000000000000000000000000000000000",
    refData: [],
    refLoader : false,
    provider: null,
    ReadProvider: new ethers.providers.JsonRpcProvider(
      process.env.REACT_APP_CRONOS_RPC
    ),
  };

  fetchMintPrice = async (data) => {
    try {
      let contractAddress = data.Contract_Address;
      const contract = new ethers.Contract(
        contractAddress,
        ERC20_ABI,
        this.state.ReadProvider
      );
      // console.log("data : ",data)
      const mintPrice = await contract.mintPrice();
      const maxMintSupply = await contract.maxMintSupply();
      const totalSupply = await contract.totalSupply();
      const value = await Convert(mintPrice / 1e18);
      const min = await contract.maxUserMintAmount();
      let balance = 0;
      let WalletAddress = sessionStorage.getItem("address");
      if (WalletAddress) {
        balance = await contract.balanceOf(sessionStorage.getItem("address"));
        balance = parseInt(balance, 16);
      }
      if (balance && balance > 0) {
        this.setState((data) => ({...data,refLoader : true}))
        axios
          .get(
            `https://deep-index.moralis.io/api/v2/${WalletAddress}/nft?chain=cronos&format=decimal&token_addresses%5B0%5D=${contractAddress}&media_items=false`,
            {
              headers: {
                "X-API-Key":
                  "t7574fu2HGiBSW8Hy51cSJ6n4ENt6qbGiJYfm8acLt7JDZRItukRP7n2STI2z2VK",
              },
            }
          )
          .then(async (response) => {
            console.log(response);
            let arr = [];
            for (let token of response.data.result) {
              let exp_date = new Date(0);
              let res = await contract.refundEndTimes(token.token_id);
              res = parseFloat(res, 16);
              exp_date.setUTCSeconds(res);
              let exp =
                new Date(exp_date) > new Date()
                  ? new Date(exp_date) - new Date()
                  : 0;
              arr.push({
                token_id: token.token_id,
                ends_in: exp,
                exp_date: new Date(exp_date),
              });
            }
            // arr = res.data.result.filter(async(item) =>  ? await contract.refundEndTimes(item.token_id) : 0 )
            this.setState({ refData: arr, refLoader : false });
            // this.setState({OpenLoader : false})
          })
          .catch((e) => {
            this.setState({ refData: [], refLoader : false });
            console.log(e);
            toast.error(
              e.data.message
                ? e.data.message
                : e?.message
                ? e?.message
                : e?.resoan,
              { autoClose: 6000 }
            );
          });
      }

      return {
        mintPrice: mintPrice / 1e18,
        MaxSupply: parseInt(maxMintSupply._hex, 16),
        totalSupply: parseInt(totalSupply._hex, 16),
        balance: balance,
        value: value,
        min: parseInt(min._hex, 16),
      };
    } catch (e) {
      console.log(e);
      toast.error(
        e?.data && e.data
          ? e.data.message
          : e?.message
          ? e?.message
          : e?.resoan,
        { autoClose: 6000 }
      );
    }
  };

  fetchData = async () => {
    try {
      this.setState((prevData) => ({ ...prevData, OpenLoader: true }));
      const response = await fetch(this.state.url);
      let data = response.status == 200 ? await response.json() : new Error();
      // this.setState((Prevdata) => ({ ...Prevdata, Data: data.data }));
      let MintPrice = await this.fetchMintPrice(data.data);
      this.setState((Prevdata) => ({
        ...Prevdata,
        Data: { ...data.data, ...MintPrice },
        OpenLoader: false,
      }));
    } catch (e) {
      console.log(e);
    }
  };

  async refund(token_id) {
    this.setState((data) => ({
      ...data,
      refundLoader: true,
      token_id: token_id,
    }));
    try {
      let address = this.state.Data.Project_Owner;
      let contractAddress = this.state.Data.Contract_Address;
      const provider = await GetProvider();
      let network = await provider.getNetwork();
      if (network.chainId != process.env.REACT_APP_NETWORK_ID) {
        this.setState((data) => ({
          ...data,
          refundLoader: false,
          token_id: token_id,
        }));
        return await switchNetwork1(process.env.REACT_APP_NETWORK_ID);
      }
      const signer = provider.getSigner();
      const daiContract = new ethers.Contract(
        contractAddress,
        ERC20_ABI,
        provider
      );

      const sign = daiContract.connect(signer);
      const status = await sign.refund(token_id);
      await status.wait();
      this.setState((data) => ({ ...data, refundLoader: false }));
      await this.fetchData();
      console.log(status);
    } catch (e) {
      console.log(e);
      this.setState((data) => ({ ...data, refundLoader: false }));
      toast.error(
        e?.reason
          ? e?.reason
          : e.error?.message
          ? e.error?.message
          : e?.message,
        { autoClose: 6000 }
      );
    }
  }

  componentDidMount() {
    this.fetchData();
  }

  mint = async (data) => {
    this.setState((data) => ({ ...data, mintLoader: true }));
    try {
      if (!sessionStorage.getItem("address")) {
        this.setState((data) => ({ ...data, mintLoader: false }));
        return toast.error("Your wallet is not connected!");
      } else if (new Date(this.state.Data.Date_of_Launch) > new Date()) {
        this.setState((data) => ({ ...data, mintLoader: false }));
        return toast.error("NFT is not lauched yet!");
      } else if (this.state.Data.totalSupply / this.state.Data.MaxSupply == 1) {
        this.setState((data) => ({ ...data, mintLoader: false }));
        return toast.error("Supply is over!");
      } else if (
        parseInt(this.state.count) + this.state.Data.totalSupply >
        this.state.Data.MaxSupply
      ) {
        this.setState((data) => ({ ...data, mintLoader: false }));
        return toast.error("Limit excide!");
      } else if (this.state.count <= 0) {
        this.setState((data) => ({ ...data, mintLoader: false }));
        return toast.error("Invalid NFT count");
      }

      let provider = await GetProvider();
      let network = await provider.getNetwork();
      if (network.chainId != process.env.REACT_APP_NETWORK_ID) {
        this.setState((data) => ({ ...data, mintLoader: false }));
        return switchNetwork1(sessionStorage.getItem("name"));
      }

      let address = this.state.Data.Project_Owner;
      // const provider = new ethers.providers.Web3Provider(window.ethereum);
      provider = await GetProvider();
      const signer = provider.getSigner();
      const daiContract = new ethers.Contract(
        this.state.Data.Contract_Address,
        ERC20_ABI,
        provider
      );
      const sign = daiContract.connect(signer);
      let options;
      let whiteListUser = await sign.whiteListedUsersList(
        sessionStorage.getItem("address")
      );

      if (whiteListUser) {
        const WLMintPrice = await sign.WLMintPrice();
        options = {
          value: (
            WLMintPrice.toString() * parseInt(this.state.count)
          ).toString(),
        };
      } else {
        const mintPrice = await sign.mintPrice();
        options = {
          value: (mintPrice.toString() * parseInt(this.state.count)).toString(),
        };
      }
      const balance = await sign.publicSaleMint(
        parseInt(this.state.count),
        this.state.ref,
        options
      );
      await balance.wait();
      toast.success("minted successfull!")
      this.setState((data) => ({ ...data, mintLoader: false, count:1 }));
      await this.fetchData();
      // console.log(balance);
    } catch (e) {
      console.log(e);
      this.setState((data) => ({ ...data, mintLoader: false }));
      toast.error(
        e?.reason
          ? e?.reason
          : e.error?.message
          ? e.error?.message
          : e?.message,
        { autoClose: 6000 }
      );
    }
  };

  youtube_parser(url) {
    if (!url) return url;
    url = url.split(/(vi\/|v=|\/v\/|youtu\.be\/|\/embed\/)/);
    return url[2] !== undefined ? url[2].split(/[^0-9a-z_\-]/i)[0] : url[0];
  }

  HandleCountChange(e) {
    this.setState((Prevdata) => ({ ...Prevdata, count: e.target.value }));
  }

  async CopyToClipboard() {
    try {
      if (!navigator?.clipboard) return toast.error("Copy is not supported!");
      this.copyText =
        window.location.origin +
        "/project/" +
        this.state.Data.Name_Of_Project.replace(/\s+/g, '-') +
        "/" +
        sessionStorage.getItem("address");

      const textarea = document.createElement("textarea");
      textarea.value = this.copyText;
      textarea.setAttribute("readonly", "");
      textarea.style.position = "absolute";
      textarea.style.left = "-9999px";
      document.body.appendChild(textarea);
      const selected =
        document.getSelection().rangeCount > 0
          ? document.getSelection().getRangeAt(0)
          : false;
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      if (selected) {
        document.getSelection().removeAllRanges();
        document.getSelection().addRange(selected);
      }
      this.setState({ textCopied: 1 });
      toast.success("Text copied successfully!", { autoClose: 6000 });
    } catch (e) {
      toast.error(
        e?.reason
          ? e?.reason
          : e.error?.message
          ? e.error?.message
          : e?.message,
        { autoClose: 6000 }
      );
      console.log(e);
    }
  }

  render() {
    return (
      <section className="item-details-area">
        <div className="container">
          <div className="row justify-content-between">
            {this.state.OpenLoader === true ? (
              <div className="col-12   d-flex align-items-center justify-content-center">
                <ClipLoader color="#36d7b7" size={70} />
              </div>
            ) : (
              <>
                <div className="col-12 col-lg-5">
                  {/* Project Card */}
                  <div className="card project-card no-hover">
                    <div className="media">
                      <img
                        className="card-img-top avatar-max-lg"
                        src={`${process.env.REACT_APP_API_URL}${this.state.Data.imgUrl}`}
                        alt=""
                      />
                      <div className="media-body ml-4">
                        <h4 className="m-0">
                          {this.state.Data.Name_Of_Project}
                        </h4>
                        {new Date(this.state.Data.Date_of_Launch*1000) >
                        new Date() ? (
                          <div className="countdown-times">
                            <h6 className="my-2">Launching in:</h6>
                            <div className="countdown d-flex">
                              <Counter date={this.state.Data.Date_of_Launch*1000} />
                            </div>
                          </div>
                        ) : (
                          <div className="countdown-times">
                            <h6 className="my-2">Lauched at:</h6>
                            <div>
                              <DateFormat date={this.state.Data.Date_of_Launch*1000}/>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                    {/* Project Body */}
                    <div className="card-body">
                      <div className="items">
                        {/* Single Item */}
                        <div className="single-item">
                          <span>Total raise : </span>
                          <span>
                            {this.state.Data.MaxSupply *
                              this.state.Data.mintPrice}{" "}
                          </span>
                        </div>
                        {/* Single Item */}
                        <div className="single-item">
                          <span>Value:</span>
                          <span>${this.state.Data.value}</span>
                        </div>
                        {/* Single Item */}
                        <div className="single-item">
                          <span>Min allo : </span>
                          <span>{this.state.Data.min}</span>
                        </div>
                      </div>
                      <div className="item-progress">
                        <div className="progress mt-4 mt-md-5">
                          <div
                            className="progress-bar"
                            role="progressbar"
                            style={{
                              width:
                                this.state.Data.totalSupply &&
                                this.state.Data.MaxSupply
                                  ? `${
                                      (this.state.Data.totalSupply /
                                        this.state.Data.MaxSupply) *
                                      100
                                    }%`
                                  : "0%",
                            }}
                            aria-valuenow={50}
                            aria-valuemin={0}
                            aria-valuemax={100}
                          >
                            {this.state.Data.totalSupply}
                          </div>
                        </div>
                        <div className="progress-sale d-flex justify-content-between mt-3">
                          <span> {this.state.Data.MaxSupply} Supply </span>
                          <span> {this.state.Data.mintPrice} CRO </span>
                        </div>
                      </div>
                    </div>
                    {/* Project Footer */}
                    <div className="project-footer d-flex align-items-center mt-4 mt-md-5">
                      {new Date(this.state.Data.Date_of_Launch) < new Date() ? (
                        <>
                          <div className="col-md-3">
                            <input
                              type="number"
                              id="Price_of_collection"
                              className="form-control"
                              onChange={(e) => this.HandleCountChange(e)}
                              value={this.state.count}
                            />
                          </div>

                          <button
                            className="btn btn-bordered-white btn-smaller"
                            disabled={this.state.mintLoader}
                            onClick={() => this.mint(this.state.Data)}
                          >
                            Mint NFT
                            {this.state.mintLoader ? (
                              <ClipLoader color="#36d7b7" size={15} />
                            ) : (
                              ""
                            )}
                          </button>
                        </>
                      ) : null}

                      {/* Social Share */}
                      <div className="social-share ml-auto">
                        <ul className="d-flex list-unstyled">
                          {this.state.Data.Twitter_Link ? (
                            <li>
                              <a href={this.state.Data.Twitter_Link}>
                                <i className="fab fa-twitter" />
                              </a>
                            </li>
                          ) : null}
                          {this.state.Data.Telegram_Link ? (
                            <li>
                              <a href={this.state.Data.Telegram_Link}>
                                <i className="fab fa-telegram" />
                              </a>
                            </li>
                          ) : null}
                          {this.state.Data.Website ? (
                            <li>
                              <a href={this.state.Data.Website}>
                                <i className="fas fa-globe" />
                              </a>
                            </li>
                          ) : null}
                          {this.state.Data.Discord_Link ? (
                            <li>
                              <a href={this.state.Data.Discord_Link}>
                                <i className="fab fa-discord" />
                              </a>
                            </li>
                          ) : null}
                        </ul>
                      </div>
                    </div>
                    {/* Blockchain Icon */}
                    <div className="blockchain-icon">
                      <img src={this.state.Data.blockchain} alt="" />
                    </div>
                  </div>
                  <>
                    {this.state.Data.balance ? (
                      <>
                        <div className="col-14 my-3">
                          <div className="card project-card no-hover">
                            Referral URL :{" "}
                            {window.location.origin +
                              "/project/" +
                              this.state.Data.Name_Of_Project +
                              "/" +
                              sessionStorage.getItem("address")}
                            <button
                              className="btn"
                              onClick={() => this.CopyToClipboard()}
                            >
                              {this.state.textCopied === 0 ? "Copy" : "Copied!"}
                            </button>
                          </div>
                        </div>
                        <div className="card project-card no-hover">
                          <div className="col-14 my-3">
                            <div
                              className="row"
                              style={{ justifyContent: "space-between" }}
                            >
                              <div className="col-14 my-3">Token id</div>
                              <div className="col-14 my-3">Ends at</div>
                              <div className="col-14 my-3">Action</div>
                            </div>
                            {
                              this.state.refLoader == false ? 
                              this.state.refData?.length > 0 ? (
                                this.state.refData.map((item, idx) => (
                                  <div
                                    className="row"
                                    style={{ justifyContent: "space-between" }}
                                    key={idx}
                                  >
                                    <div className="col-14 my-3">
                                      {item.token_id}
                                    </div>
                                    <>
                                      {item.ends_in > 0 ? (
                                        <>
                                          <div className="col-14 my-3 ">
                                            {new Date(
                                              item.exp_date
                                            ).toLocaleString()}
                                          </div>
                                          <div className="col-14 my-3">
                                            <button
                                              className="bg-transparent font-semibold py-2 px-4 border text-white"
                                              disabled={this.state.refundLoader}
                                              onClick={() =>
                                                this.refund(item.token_id)
                                              }
                                            >
                                              Refund
                                              {this.state.refundLoader &&
                                              item.token_id ===
                                                this.state.token_id ? (
                                                <ClipLoader
                                                  color="#36d7b7"
                                                  size={15}
                                                />
                                              ) : (
                                                ""
                                              )}
                                            </button>
                                          </div>{" "}
                                        </>
                                      ) : (
                                        <>
                                          <div className="col-14 my-3">Ended</div>{" "}
                                        </>
                                      )}
                                    </>
                                  </div>
                                ))) : <div>No data available!</div> :
                                <div>Loading...</div>
                            }
                          </div>
                        </div>
                      </>
                    ) : null}
                  </>
                </div>
                <div className="col-12 col-lg-7 items mt-5 mt-lg-0">
                  <div className="card project-card single-item-content no-hover item ml-lg-4">
                    <h3 className="m-0">Project Summary</h3>
                    <p>{this.state.Data.Project_Summary}</p>
                  </div>
                  {this.state.Data.Video !== "" ? (
                    <div className="card project-card single-item-content no-hover item p-0 ml-lg-4">
                      <div className="image-over">
                        <img
                          className="card-img-top"
                          src={`https://img.youtube.com/vi/${this.youtube_parser(
                            this.state.Data.Video
                          )}/sddefault.jpg`}
                          alt=""
                        />
                      </div>
                      <div className="card-caption col-12 p-0">
                        <div className="card-body p-0">
                          <div className="play-btn gallery display-yes">
                            <a href={this.state.Data.Video}>
                              <i className="fa-solid fa-play" />
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : null}
                  <div className="card project-card single-item-content no-hover item ml-lg-4">
                    <h3 className="m-0">Project Overview</h3>
                    {parse(this.state.Data.Project_Overview)}
                  </div>
                  {/* <div className="card project-card single-item-content no-hover item ml-lg-4">
                  <h3 className="m-0">{this.state.tokenmetricsData.title}</h3>
                  <p>{this.state.tokenmetricsData.content}</p>
                  <div className="table-responsive">
                    <table className="table token-content table-borderless table-sm">
                      <tbody>
                   
                        <tr key="1">
                          <td>Raffle</td>
                          <td>
                            Raffle will be posted live on Youtube, using Google
                            random number generator
                          </td>
                        </tr>
                        <tr key="2">
                          <td>Platfrom Raise:</td>
                          <td>7500 Cro </td>
                        </tr>
                        <tr key="3">
                          <td>Price:</td>
                          <td>{this.state.Data.mintPrice} Cro</td>
                        </tr>
                        <tr key="4">
                          <td>Prize payout</td>
                          <td>
                            1 x Cronos Cruiser to Raffle Winner, rest of
                            proceeds to Pesky Kanga's
                          </td>
                        </tr>
                      
                      </tbody>
                    </table>
                  </div>
                </div> */}
                  <div className="card project-card single-item-content no-hover item ml-lg-4">
                    <h3 className="m-0">Roadmap Summary</h3>
                    {parse(this.state.Data.Roadmap_Summary)}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </section>
    );
  }
}

export default Project;
