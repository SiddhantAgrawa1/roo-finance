import React, { useEffect, useState } from "react";

export default function Counter({date}){

    const [Count,setCount]  = useState(date)

    useEffect(() => {
        // console.log("Called")
        setInterval(() => {
            let count = new Date(date).getTime()-new Date().getTime()
            if(count > 0 )
                setCount(() => count)
            else 
                setCount(() => false)
        },1000)   
    },[])

    return(
        <>
        {   
            Count == false ? "" :
            <>
            {Count !== date ? Math.floor(Count / (1000 * 60 * 60 * 24)).toString() : '--'} D {' '}
            {Count !== date ? Math.floor((Count % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)).toString() : '--'} H {' '}
            {Count !== date ? Math.floor((Count % (1000 * 60 * 60)) / (1000 * 60)).toString() : '--'} M {' '}
            {Count !== date ? Math.floor((Count % (1000 * 60)) / 1000).toString() : '--/--'} S
            {/* {console.log(Count)} */}
            </>
        }
        </>
    )
}