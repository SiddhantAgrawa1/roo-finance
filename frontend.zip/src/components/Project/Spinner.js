import React from 'react';

const Spinner = () => {
  const loaderStyles = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
  };

  const spinnerStyles = {
    border: '4px solid rgba(0, 0, 0, 0.1)',
    borderTopColor: '#1a1a1a',
    borderRadius: '50%',
    width: '32px',
    height: '32px',
    animation: 'spin 1s ease-in-out infinite',
  };

  return (
    <div style={loaderStyles}>
      <div style={spinnerStyles}></div>
    </div>
  );
};

export default Spinner;
