import React, { useEffect, useState } from "react";
import Loader from "../Project/Loader";
import { toast } from 'react-toastify'
import { ethers } from "ethers";
import ERC20_ABI from "../ContractData/bsc.json";

export default function Mint() {
    const [Count,setCount] = useState(1)
    const [MintPrice,setMintPrice] = useState()
    const [totalSupply,setTotalSupply] = useState()
    const [Sign,setSigner] = useState();
    const [Address,setAddress] = useState()
    
    function incrementCount(){
        console.log(Count)
        if(Count !== 10000 ) setCount((Count) => Count + 1)
    }
    function decrementCount(){
        if(Count !== 1) setCount((Count) => Count - 1)
    }

    useEffect(() => {
        fetchMintPrice()
    },[])

    const fetchMintPrice = async () => {
        // this.setState((data) => ({...data, OpenLoader : true}))
        let Name_Of_Project = "new project 34"
        try {
          let contractAddress = "";
          let address = ""
          const response = await fetch(`${process.env.REACT_APP_API_URL}project/${Name_Of_Project}`);
          const data = await response.json();
          if (data.status == 200) {
            console.log(data);
            contractAddress = data.data.Contract_Address;
            address = data.data.Project_Owner 
            console.log(contractAddress);
          }
    
          const provider = new ethers.providers.Web3Provider(window.ethereum);
          const signer = provider.getSigner();
          // const address = sessionStorage.getItem("address");
          // const address = "0xC92453EE4E8C5779051dEea7700a6B0c6710eB04"
          const daiContract = new ethers.Contract(
            // "0x5032647712f1668aBA3D27219088d4631CEfB01f",
            contractAddress,
            ERC20_ABI,
            provider
          );
          console.log("contract address : ", daiContract.address);
          const sign = daiContract.connect(signer);
          setSigner(() => sign)
          setAddress(() => address)
          console.log("sign", sign);
          console.log("Address : ",address)
          // ;
          const mintPrice = await sign.mintPrice()
          const options = { value: ethers.utils.parseEther(mintPrice.toString())};
          console.log(parseInt(mintPrice,16))
          setMintPrice(parseInt(mintPrice,16))
        } catch (e) {
          console.log(e);
        //   this.setState((data) => ({...data, OpenLoader : false}))
          toast.error(e.data.message ? e.data.message : e?.message ? e?.message : e?.resoan, { autoClose: 6000 });
        }
      };

    const mint = async () => {
        
        try {
          const total = MintPrice * Count 
          const options = { value: ethers.utils.parseEther(total.toString())};
          const balance = await Sign.publicSaleMint(Count, Address,options);
        //   this.setState((data) => ({...data, OpenLoader : false}))
          console.log(balance);
        } catch (e) {
          console.log(e);
        //   this.setState((data) => ({...data, OpenLoader : false}))
          toast.error(e.data.message ? e.data.message : e?.message ? e?.message : e?.resoan, { autoClose: 6000 });
        }
      };

  return (
    <div>
      <div className="card project-card w-50">
        <div className="border-white-500 border">
        Minted Supply 
        <h3>1259</h3>
        {console.log(MintPrice)}
        Mint Price : {MintPrice}
        <div className="d-flex border-white-500 border items-center" style={{width : "100px"}}>
            <button style={{border : "2px solid white", width:"30px",height:"30px",textAlign:"center", fontSize:"2rem"}} onClick={() => decrementCount()}>-</button>
            <div style={{border : "2px solid white", width:"30px",height:"30px",textAlign:"center", fontSize:"1rem"}}>{Count}</div>
            <button style={{border : "2px solid white", width:"38px",height:"30px",textAlign:"center", fontSize:"1.5rem"}} onClick={() => incrementCount()}>+</button>
        </div>
        Total {MintPrice*Count} CRO <br/>
        <button onClick={() => mint()}>Mint</button> <br/>
        Your Referral URL : 
        </div>
        <div>
            Your accomadated Referral earnings : CRO  <br/>
            <button>Withdraw</button>
        </div>
        <div>
            Mint Details <br/>
            {new Date().toLocaleDateString()}<br/>
            Total Supply : {MintPrice*Count}  <br/>
            Price :{MintPrice} CRO 
        </div>
      </div>

    </div>
  );
}
