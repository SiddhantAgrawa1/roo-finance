import React, { Component } from "react";
import SwiperCore, { Autoplay } from "swiper";
import { Navigation, Pagination, Scrollbar, A11y } from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";
import { ethers } from "ethers";
// import ERC20_ABI from "../ContractData/bsc.json";
import { toast } from "react-toastify";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/autoplay";
import Counter from "./Counter";
import Loader from "../Project/Loader";
import { Link } from "react-router-dom";
import { Convert } from "./ConvertMintPrice";
import { ClipLoader } from "react-spinners";
import { fetchContractDetails } from "../Service/ContractService";
import DateFormat from "./DateFormat";

SwiperCore.use([Autoplay]);

const initData = {
  sub_heading: "Projects",
  heading: "Launches",
  btn: "View More",
  actionBtn: "Mint",
};

class ProjectOne extends Component {
  constructor(props) {
    super(props);
    this.state = {
      initData: initData,
      data: [],
      OpenLoader: false,
    };
  }

  fetchData = async () => {
    try {
      this.setState((prevData) => ({ ...prevData, OpenLoader: true }));
      const response = await fetch(`${process.env.REACT_APP_API_URL}projects/notended`);
      let Data = response.status == 200 ? await response.json() : toast.error(response.data ? response.data.message : response.statusText)
      let data = Data && Data.data ? Data.data : []
      this.setState(() => ({
        initData: initData,
        data: data.length > 7 ? [...data.slice(0, 7)] : data,
        OpenLoader: false
      }));
      let projects = await fetchContractDetails(data);
      this.setState(() => ({
        initData: initData,
        data: projects.length > 7 ? [...projects.slice(0, 7)] : projects,
      }));
    } catch (e) {
      this.setState((prevData) => ({ ...prevData, OpenLoader: false }));
      console.log("Error", e);
    }
  };

  componentDidMount() {
    this.fetchData();
  }

  render() {
    return (
      <section id="explore" className="project-area">
       
        <div className="container">
          <div className="row">
            <div className="col-12">
              {/* Intro */}
              <div className="intro d-flex justify-content-between align-items-end mb-2">
                <div className="intro-content">
                  <span className="intro-text">
                    {this.state.initData.sub_heading}
                  </span>
                  <h3 className="mt-3 mb-0">{this.state.initData.heading}</h3>
                </div>
                <div className="intro-btn">
                  <Link className="btn content-btn" to="/projects">
                    {this.state.initData.btn}
                  </Link>
                </div>
              </div>
            </div>
          </div>

          {this.state.OpenLoader === false ? 
            this.state.data.length !== 0 ? (
              <Swiper
              // install Swiper modules
              modules={[Navigation, Pagination, Scrollbar, A11y]}
              spaceBetween={30}
              slidesPerView={1}
              pagination={{
                el: ".my-custom-pagination-div",
                clickable: true,
              }}
              breakpoints={{
                // when window width is >= 766px
                766: {
                  slidesPerView: 2,
                  spaceBetween: 20,
                },
                // when window width is >= 1022px
                1022: {
                  slidesPerView: 3,
                  spaceBetween: 30,
                },
              }}
              autoplay={{
                delay: 5000,
                disableOnInteraction: false,
              }}
              freeMode
            >
              {this.state.data.map((item, idx) => {
                return (
                  <SwiperSlide key={`pd_${idx}`}>
                    {/* <div  className="swiper-slide item"> */}
                    {
                      <div className="card project-card">
                        <div className="media">
                          <a href={`/project/${item.Name_Of_Project.replace(/\s+/g, '-')}`}>
                            <img
                              className="card-img-top avatar-max-lg"
                              src={`${process.env.REACT_APP_API_URL}${item.imgUrl}`}
                              alt=""
                            />
                          </a>
                          <div className="media-body ml-4">
                            <a href={`/project/${item.Name_Of_Project.replace(/\s+/g, '-')}`}>
                              <h4 className="m-0">{item.Name_Of_Project}</h4>
                            </a>
                            {new Date(item.Date_of_Launch) > new Date() ? (
                              <div className="countdown-times">
                                <h6 className="my-2">Launching in:</h6>
                                <div className="countdown d-flex">
                                  <Counter date={item.Date_of_Launch} />
                                </div>
                              </div>
                            ) : (
                              <div className="countdown-times">
                                <h6 className="my-2">Lauched at:</h6>
                                <div> <DateFormat date={item.Date_of_Launch}/> </div>
                              </div>
                            )}
                          </div>
                        </div>
                        {/* Project Body */}
                        <div className="card-body">
                          <div className="items">
                            {/* Single Item */}
                            <div className="single-item">
                              <span>Total raise : </span>
                              <span> {(item.MaxSupply * item.mintPrice) ? item.MaxSupply * item.mintPrice : '--'}</span>
                            </div>
                            {/* Single Item */}
                            <div className="single-item">
                              <span>Value : </span>
                              <span>{item.value ? item.value : '--'}</span>
                            </div>
                            {/* Single Item */}
                            {/* <div className="single-item">
                              <span>Verified</span>
                              <span> {item.allocation}</span>
                            </div> */}

                            <div className="progress-sale d-flex justify-content-between mt-3">
                              <span>{item.MaxSupply?item.MaxSupply:'--'} SUPPLY</span>
                              <span>{ item.mintPrice ? item.mintPrice : '--'} CRO</span>
                            </div>
                          </div>
                        </div>
                        {/* Project Footer */}
                        <div className="project-footer d-flex align-items-center mt-4 mt-md-5">
                        <a
                            className={`btn btn-bordered-white btn-smaller`}
                            onClick={() => window.location.href = `/project/${item.Name_Of_Project.replace(/\s+/g, '-')}`}
                          >
                            Mint
                          </a>
                          {/* Social Share */}
                          <div className="social-share ml-auto">
                            <ul className="d-flex list-unstyled">
                            { item.Twitter_Link ? 
                              <li> <a href={item.Twitter_Link}> <i className="fab fa-twitter" /></a> </li>
                              : null 
                            }
                            { item.Telegram_Link ? 
                              <li> <a href={item.Telegram_Link}> <i className="fab fa-telegram" /></a> </li>
                              : null 
                            }
                            { item.Website ? 
                              <li> <a href={item.Website}> <i className="fas fa-globe" /></a> </li>
                              : null 
                            }
                            { item.Discord_Link ? 
                              <li> <a href={item.Discord_Link}> <i className="fab fa-discord" /></a> </li>
                              : null 
                            }
                            </ul>
                          </div>
                        </div>
                        {/* Blockchain Icon */}
                        <div className="blockchain-icon">
                          <img src={item.blockchain} alt="" />
                        </div>
                      </div>
                    }
                    
                    {/* </div> */}
                  </SwiperSlide>
                );
              })}
              <SwiperSlide key='9' className="morevirecard" >
              <div className="card project-card morebuttons" style={{cursor : "pointer"}}>
                <Link to='/projects'>
                <i class="fa-solid fa-plus"></i>
                 </Link></div>

              </SwiperSlide>
              </Swiper>
            ) : <div className="col-12 text-center"> No data found! </div> : 
              (
                <div className="col-12   d-flex align-items-center justify-content-center">
                <ClipLoader color="#36d7b7" size={70} />
                </div>
              )}

          <div className="container text-center">
            <div className="my-custom-pagination-div mt-2 flex item-center justify-center" />
          </div>
        </div>
      </section>
    );
  }
}

export default ProjectOne;
