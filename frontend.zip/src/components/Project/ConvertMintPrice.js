const {REACT_APP_API_URL} = process.env;
export const Convert = async(price) => {
    try{
    const response = await fetch('https://coincodex.com/api/coincodex/get_coin/cro');
    if(response.status == 200){
        const data = await response.json();
        const usdPrice = price * data.last_price_usd
        return usdPrice.toFixed(4)
    }
    }catch(error){
        console.log(error)
    }
}