import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import apiService from "../Service/axios/ApiService";
import { toast } from "react-toastify";
import Cards from "./Cards";
import { ClipLoader } from "react-spinners";
import { fetchContractDetails } from "../Service/ContractService";
import { ethers } from "ethers";
import ERC20_ABI from "../ContractData/bsc.json";
import { Convert } from "./ConvertMintPrice";
import axios from "axios";

const initData = {
  sub_heading: "Exclusive",
  heading: "Kanga LaunchPad",
  content: "Take a look at our upcoming projects... ",
  actionBtn: "Mint",
  filter_1: "All",
  filter_2: "Ongoing",
  filter_3: "Upcoming",
  filter_4: "Ended ",
};

function ProjectsNew() {
  const [data, setData] = useState([]);
  const [filter, setFilter] = useState('projects');
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchData();
  }, [filter, page]);

  const fetchData = async () => {
    try {
      setLoading(true);
      setData([])
      const response = await apiService().get(`${filter}?page=${page}`);
      const newData = response.data.data;
      setData((prevData) => (page === 1 ? newData : [...prevData, ...newData]));
    } catch (error) {
      if (axios.isCancel(error)) {
        console.log('Request canceled', error.message);
      } else {
        console.error(error);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleFilterClick = (selectedFilter) => {
    setFilter(selectedFilter);
    setPage(1);
  };

  const handleLoadMoreClick = () => {
    setPage((prevPage) => prevPage + 1);
  };

  return (
    <>
      <section className="project-area explore-area">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-12 col-md-8 col-lg-7">
              {/* Intro */}
              <div className="intro text-center">
                <div className="intro-content">
                  <span className="intro-text">{initData.sub_heading}</span>
                  <h3 className="mt-3 mb-0">{initData.heading}</h3>
                  <p>{initData.content}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="row justify-content-center text-center">
            <div className="col-12">
              {/* Explore Menu */}
              <div
                className="explore-menu btn-group btn-group-toggle flex-wrap justify-content-center text-center mb-md-4"
                data-toggle="buttons"
              >
                <label
                  className="btn active d-table text-uppercase p-2"
                  onClick={() => handleFilterClick('projects')}
                >
                  <input
                    type="radio"
                    defaultValue="all"
                    defaultChecked
                    className="explore-btn"
                  />
                  <span>{initData.filter_1}</span>
                </label>
                <label
                  className="btn d-table text-uppercase p-2"
                  onClick={async() => handleFilterClick('projects/ongoing')}
                >
                  <input
                    type="radio"
                    defaultValue="ongoing"
                    className="explore-btn"
                  />
                  <span>{initData.filter_2}</span>
                </label>
                <label
                  className="btn d-table text-uppercase p-2"
                  onClick={() => handleFilterClick('projects/upcoming')}
                >
                  <input
                    type="radio"
                    defaultValue="upcoming"
                    className="explore-btn"
                  />
                  <span>{initData.filter_3}</span>
                </label>

                <label
                  className="btn d-table text-uppercase p-2"
                  onClick={() => handleFilterClick('projects/ended')}
                >
                  <input
                    type="radio"
                    defaultValue="ended"
                    className="explore-btn"
                  />
                  <span>{initData.filter_4}</span>
                </label>
              </div>
            </div>
          </div>

          <div
            className="row  items inner"
            style={{ width: "100%", height: "auto !important" }}
          >
            {loading && (
              <div className="container text-center">
                <ClipLoader color="#36d7b7" size={70} />
              </div>
            )}

            {data.length === 0 && !loading && <div>No data found.</div>}

            {data.length > 0 ? <Cards data={data} /> : ""}

            {/* {data.length > 0 && (
              <button onClick={handleLoadMoreClick} disabled={loading}>
                Load More
              </button>
            )} */}
          </div>
        </div>
      </section>
    </>
  );
}

export default ProjectsNew;
