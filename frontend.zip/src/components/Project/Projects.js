import React, { Component } from "react";
import Counter from "./Counter";
import Loader from "../Project/Loader";
import { toast } from "react-toastify";
import { ethers } from "ethers";
import ERC20_ABI from "../ContractData/bsc.json";
import { Convert } from "./ConvertMintPrice";
import { ClipLoader } from "react-spinners";
import { fetchContractDetails } from "../Service/ContractService";
import Cards from "./Cards";

const initData = {
  sub_heading: "Exclusive",
  heading: "Kanga LaunchPad",
  content: "Take a look at our upcoming projects... ",
  actionBtn: "Mint",
  filter_1: "All",
  filter_2: "Ongoing",
  filter_3: "Upcoming",
  filter_4: "Ended ",
};

class ProjectFour extends Component {
  constructor(props) {
    super(props);
    this.state = {
      initData: initData,
      all: [],
      upcoming: [],
      ongoing: [],
      ended: [],
      OpenLoader: false,
      CurrentPage: 0,
      totalPage: 0,
      filter: 1,
    };
  }

  All = async (checkNew) => {
    try {
      checkNew == true
        ? this.setState((prevData) => ({
            ...prevData,
            OpenLoader: true,
            CurrentPage: 0,
            all: [],
            ended: [],
            ongoing: [],
            upcoming: [],
          }))
        : this.setState((prevData) => ({ ...prevData, OpenLoader: true }));
      let currentPage = checkNew == true ? 0 : this.state.CurrentPage;
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}projects?page=${currentPage + 1}`
      );
      let Data =
        response.status === 200
          ? await response.json()
          : toast.error(
              response.data ? response.data.message : response.statusText
            );
      let data = Data && Data.data ? Data.data : [];
      const projects = data.length > 0 ? await fetchContractDetails(data) : [];
      // console.log("Projects ", projects);
      this.setState((prevData) => ({
        ...prevData,
        initData: initData,
        all: [...prevData.all, ...projects],
        ended: [],
        ongoing: [],
        upcoming: [],
        CurrentPage: Data.currentPage,
        totalPage: Data.totalPages,
        OpenLoader: false,
        filter: 1,
      }));
    } catch (e) {
      this.setState((prevData) => ({ ...prevData, OpenLoader: false }));
      console.log("Error", e);
      // toast.error(
      //   e?.reason
      //     ? e?.reason
      //     : e.error?.message
      //     ? e.error?.message
      //     : e?.message,
      //   { autoClose: 6000 }
      // );
    }
  };

  fetchMintPrice = async (data) => {
    try {
      let contractAddress = data.Contract_Address;

      const provider = new ethers.providers.JsonRpcProvider(
        process.env.REACT_APP_CRONOS_RPC
      );
      const contract = new ethers.Contract(
        contractAddress,
        ERC20_ABI,
        provider
      );

      const mintPrice = await contract.mintPrice();
      const maxMintSupply = await contract.maxMintSupply();
      const totalSupply = await contract.totalSupply();
      const value = await Convert(mintPrice / 1e18);

      return {
        mintPrice: mintPrice / 1e18,
        MaxSupply: parseInt(maxMintSupply._hex, 16),
        totalSupply: parseInt(totalSupply, 16),
        value: value,
      };
    } catch (e) {
      console.log(e);
      //   this.setState((data) => ({...data, OpenLoader : false}))
      // toast.error(
      //   e.data.message ? e.data.message : e?.message ? e?.message : e?.resoan,
      //   { autoClose: 6000 }
      // );
    }
  };

  async componentDidMount() {
    await this.All(true);
  }

  Upcoming = async (checkNew) => {
    try {
      checkNew == true
        ? this.setState((prevData) => ({
            ...prevData,
            OpenLoader: true,
            CurrentPage: 0,
            all: [],
            ended: [],
            ongoing: [],
            upcoming: [],
          }))
        : this.setState((prevData) => ({ ...prevData, OpenLoader: true }));
      let currentPage = checkNew == true ? 0 : this.state.CurrentPage;
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}projects?page=${currentPage + 1}`
      );

      let Data =
        response.status === 200
          ? await response.json()
          : toast.error(
              response.data ? response.data.message : response.statusText
            );
      let data = Data && Data.data ? Data.data : [];
      data = data.filter((item) => new Date(item.Date_of_Launch) > new Date());
      const projects = data.length > 0 ? await fetchContractDetails(data) : [];

      this.setState((prevData) => ({
        ...prevData,
        initData: initData,
        all: [],
        ended: [],
        ongoing: [],
        upcoming: [...prevData.upcoming, ...projects],
        CurrentPage: Data.currentPage,
        totalPage: Data.totalPages,
        OpenLoader: false,
        filter: 3,
      }));
    } catch (e) {
      this.setState((prevData) => ({ ...prevData, OpenLoader: false }));
      console.log("Error", e);
      toast.error(
        e?.reason
          ? e?.reason
          : e.error?.message
          ? e.error?.message
          : e?.message,
        { autoClose: 6000 }
      );
    }
  };

  Ongoing = async (checkNew) => {
    try {
      // debugger
      checkNew == true
        ? this.setState((prevData) => ({
            ...prevData,
            OpenLoader: true,
            CurrentPage: 0,
            all: [],
            ended: [],
            ongoing: [],
            upcoming: [],
          }))
        : this.setState((prevData) => ({ ...prevData, OpenLoader: true }));
      let currentPage = checkNew == true ? 0 : this.state.CurrentPage;
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}projects?page=${currentPage + 1}`
      );

      let Data =
        response.status === 200
          ? await response.json()
          : toast.error(
              response.data ? response.data.message : response.statusText
            );
      let data = Data && Data.data ? Data.data : [];
      data = data.filter((item) => new Date(item.Date_of_Launch) < new Date());
      let projects = data.length > 0 ? await fetchContractDetails(data) : [];
      projects = projects.filter((item) => item.MaxSupply > item.totalSupply);
      // console.log("Ongoing",this.state)
      this.setState((prevData) => ({
        ...prevData,
        initData: initData,
        all: [],
        upcoming: [],
        ended: [],
        ongoing: [...prevData.ongoing, ...projects],
        CurrentPage: Data.currentPage,
        totalPage: Data.totalPages,
        OpenLoader: false,
        filter: 2,
      }));
    } catch (e) {
      this.setState((prevData) => ({ ...prevData, OpenLoader: false }));
      console.log("Error", e);
      toast.error(
        e?.reason
          ? e?.reason
          : e.error?.message
          ? e.error?.message
          : e?.message,
        { autoClose: 6000 }
      );
    }
  };

  ended = async (checkNew) => {
    try {
      checkNew == true
        ? this.setState((prevData) => ({
            ...prevData,
            OpenLoader: true,
            CurrentPage: 0,
            all: [],
            ended: [],
            ongoing: [],
            upcoming: [],
          }))
        : this.setState((prevData) => ({ ...prevData, OpenLoader: true }));
      let currentPage = checkNew == true ? 0 : this.state.CurrentPage;
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/projects/ended?page=${
          currentPage + 1
        }`
      );

      let Data =
        response.status === 200
          ? await response.json()
          : toast.error(
              response.data ? response.data.message : response.statusText
            );
      let data = Data && Data.data ? Data.data : [];
      const projects = data.length > 0 ? await fetchContractDetails(data) : [];

      // projects = projects.filter((item) => item.totalSupply / item.MaxSupply == 1)
      this.setState((prevData) => ({
        ...prevData,
        initData: initData,
        all: [],
        upcoming: [],
        ongoing: [],
        ended: [...prevData.ended, ...projects],
        CurrentPage: Data.currentPage,
        totalPage: Data.totalPages,
        OpenLoader: false,
        filter: 4,
      }));
    } catch (e) {
      this.setState((prevData) => ({ ...prevData, OpenLoader: false }));
      console.log("Error", e);
      // toast.error(
      //   e?.reason
      //     ? e?.reason
      //     : e.error?.message
      //     ? e.error?.message
      //     : e?.message,
      //   { autoClose: 6000 }
      // );
    }
  };

  fetchMoreData = async () => {
    try {
      let filter = this.state.filter;
      if (filter === 1) await this.All(false);
      else if (filter === 2) await this.Ongoing(false);
      else if (filter === 3) await this.Upcoming(false);
      else if (filter === 4) await this.end(false);
    } catch (error) {
      console.log("Error : ", error);
    }
  };

  callContractFun = async (data) => {
    let projects = [];
    for (let project of data) {
      let price = await this.fetchMintPrice(project);
      projects.push({ ...project, ...price });
    }
    return projects;
  };

  render() {
    return (
      <>
        <section className="project-area explore-area">
          {/* {this.state.OpenLoader === true ? <Loader /> : null} */}
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-12 col-md-8 col-lg-7">
                {/* Intro */}
                <div className="intro text-center">
                  <div className="intro-content">
                    <span className="intro-text">
                      {this.state.initData.sub_heading}
                    </span>
                    <h3 className="mt-3 mb-0">{this.state.initData.heading}</h3>
                    <p>{this.state.initData.content}</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="row justify-content-center text-center">
              <div className="col-12">
                {/* Explore Menu */}
                <div
                  className="explore-menu btn-group btn-group-toggle flex-wrap justify-content-center text-center mb-md-4"
                  data-toggle="buttons"
                >
                  <label
                    className="btn active d-table text-uppercase p-2"
                    onClick={async () => await this.All(true)}
                  >
                    <input
                      type="radio"
                      defaultValue="all"
                      defaultChecked
                      className="explore-btn"
                    />
                    <span>{this.state.initData.filter_1}</span>
                  </label>
                  <label
                    className="btn d-table text-uppercase p-2"
                    onClick={async () => await this.Ongoing(true)}
                  >
                    <input
                      type="radio"
                      defaultValue="ongoing"
                      className="explore-btn"
                    />
                    <span>{this.state.initData.filter_2}</span>
                  </label>
                  <label
                    className="btn d-table text-uppercase p-2"
                    onClick={async () => await this.Upcoming(true)}
                  >
                    <input
                      type="radio"
                      defaultValue="upcoming"
                      className="explore-btn"
                    />
                    <span>{this.state.initData.filter_3}</span>
                  </label>
                  <label
                    className="btn d-table text-uppercase p-2"
                    onClick={async () => await this.ended(true)}
                  >
                    <input
                      type="radio"
                      defaultValue="ended"
                      className="explore-btn"
                    />
                    <span>{this.state.initData.filter_4}</span>
                  </label>
                </div>
              </div>
            </div>
            <div
              className="row  items inner"
              style={{ width: "100%", height: "auto !important" }}
            >
              {this.state.OpenLoader === true ? (
                <div className="container text-center">
                  <ClipLoader color="#36d7b7" size={70} />
                </div>
              ) : null}

              {this.state.OpenLoader == false
                ? (() => {
                    console.log(this.state.filter);
                    switch (this.state.filter) {
                      case 1:
                        return this.state.all.length === 0 ? (
                          <div className="container text-center">
                            No Data Available.
                          </div>
                        ) : (
                          <Cards data={this.state.all} />
                        );
                      case 2:
                        return this.state.ongoing.length === 0 ? (
                          <div className="container text-center">
                            No Data Available.
                          </div>
                        ) : (
                          <Cards data={this.state.ongoing} />
                        );
                      case 3:
                        return this.state.upcoming.length === 0 ? (
                          <div className="container text-center">
                            No Data Available.
                          </div>
                        ) : (
                          <Cards data={this.state.upcoming} />
                        );
                      case 4:
                        return this.state.ended.length === 0 ? (
                          <div className="container text-center">
                            No Data Available.
                          </div>
                        ) : (
                          <Cards data={this.state.ended} />
                        );
                    }
                  })()
                : null}

              {this.state.CurrentPage !== 0 &&
              this.state.OpenLoader === true ? (
                <div className="container text-center">
                  
                  <button className="btn btn-bordered-white mt-4 mt-md-5 disabled">
                    Loading...
                  </button>
                </div>
              ) : null}

                {/* {console.log("Current Page : ",this.state.CurrentPage)}
                {console.log("Open Loader ",this.state.OpenLoader)}
                {console.log("Total Page : ",this.state.totalPage)} */}

              {this.state.CurrentPage !== 0 &&
              this.state.OpenLoader === false &&
              this.state.CurrentPage < this.state.totalPage ? (
                <div className="container text-center">
                  <button
                    className="btn btn-bordered-white mt-4 mt-md-5"
                    onClick={async () => await this.fetchMoreData()}
                  >
                    Load More
                  </button>
                </div>
              ) : null}
            </div>
          </div>
        </section>
      </>
    );
  }
}

export default ProjectFour;
