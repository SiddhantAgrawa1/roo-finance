import React from "react";

function DateFormat({ date }) {
    const formattedDate = new Date(date).toLocaleString("en-US", {
        weekday: "short",
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        timeZone: "UTC",
      });
  return (
   <>
    {formattedDate} UTC
   </>
  );
}

export default DateFormat;
