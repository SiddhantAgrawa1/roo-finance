import React, { Component } from "react";
import { toast } from "react-toastify";
import { ethers } from "ethers";
import ERC20_ABI from "../ContractData/bsc.json";
import { ClipLoader } from "react-spinners";

const initData = {
  sub_heading: "Exclusive",
  heading: "Previous Launches",
  btn: "View All",
  actionBtn: "Load More",
};

class ProjectTwo extends Component {
  state = {
    initData: {},
    data: [],
    OpenLoader: false,
    CurrentPage: 0,
    totalPage: 0,
  };

  fetchData = async () => {
    try {
      this.setState((prevData) => ({
        ...prevData,
        OpenLoader: true,
      }));

      const response = await fetch(
        `${process.env.REACT_APP_API_URL}projects/ended?page=${
          this.state.CurrentPage + 1
        }`
      );

      let Data = response.status == 200 ? await response.json() : toast.error(response.data ? response.data.message : response.statusText);
      let data = Data && Data?.data ? Data.data : [];
      const projects = await this.callContractFun(data);

      this.setState((prevData) => ({
        ...prevData,
        initData: initData,
        data: [...prevData.data, ...projects],
        CurrentPage: Data.currentPage,
        totalPage: Data.totalPages,
        OpenLoader: false,
      }));
    } catch (e) {
      this.setState((prevData) => ({ ...prevData,OpenLoader: false }));
      console.log("Error", e);
      // toast.error( e?.reason ? e?.reason : e.error?.message ? e.error?.message : e?.message);
    }
  };

  fetchMintPrice = async (data,provider) => {
    try {
      let contractAddress = data.Contract_Address;

      const contract = new ethers.Contract(
        contractAddress,
        ERC20_ABI,
        provider
      );

      const mintPrice = await contract.mintPrice();
      const maxMintSupply = await contract.maxMintSupply();
      const totalSupply = await contract.totalSupply();

      return {
        mintPrice: mintPrice / 1e18,
        MaxSupply: parseInt(maxMintSupply, 16),
        totalSupply: parseInt(totalSupply, 16),
      };
    } catch (e) {
      console.log(e);
      toast.error(
        e?.reason
          ? e?.reason
          : e.error?.message
          ? e.error?.message
          : e?.message,
        { autoClose: 6000 }
      );
    }
  };

  callContractFun = async (data) => {
    let projects = [];
    const provider = new ethers.providers.JsonRpcProvider(
      process.env.REACT_APP_CRONOS_RPC
    );
    for (let project of data) {
      let price = await this.fetchMintPrice(project,provider);
      projects.push({ ...project, ...price });
    }
    return projects;
  };

  componentDidMount() {
    this.fetchData();
  }

  render() {
    return (
      <section className="explore-area prev-project-area load-more p-0">
        <div className="container">
          <div className="row">
            <div className="col-12">
              {/* Intro */}
              <div className="intro d-flex justify-content-between align-items-end m-0">
                <div className="intro-content">
                  <span className="intro-text">
                    {this.state.initData.sub_heading}
                  </span>
                  <h3 className="mt-3 mb-0">{this.state.initData.heading}</h3>
                </div>
                <div className="intro-btn">
                  <a className="btn content-btn" href="/projects">
                    {this.state.initData.btn}
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div className="row items">
            {this.state.OpenLoader == false && this.state.data.length > 0
              ? this.state.data.map((item, idx) => {
                  return (
                    <div key={`pdt_${idx}`} className="col-12 item">
                      <div className="card project-card prev-project-card">
                        <div className="project-content d-md-flex flex-column flex-md-row align-items-center justify-content-md-between">
                          <div className="item-header d-flex align-items-center mb-4 mb-md-0">
                            <img
                              className="card-img-top avatar-max-lg"
                              src={`${process.env.REACT_APP_API_URL}${item.imgUrl}`}
                              alt=""
                            />
                            <div className="content ml-4">
                              <h4 className="m-0">{item.Name_Of_Project}</h4>
                              <h6 className="mt-3 mb-0">
                                {item.mintPrice ? item.mintPrice : "--"}
                              </h6>
                            </div>
                          </div>
                          <div className="blockchain d-inline-block mr-1 mr-md-0">
                            <img src={item.blockchain} alt="" />
                          </div>
                    
                        </div>
                        <a className="project-link" href="/projects" />
                      </div>
                    </div>
                  );
                })
              : null }
          </div>
    

          <div className="row">
            <div className="col-12 text-center">
              {this.state.OpenLoader == false ? (
                this.state.CurrentPage < this.state.totalPage ? (
                  <a
                    id="load-btn"
                    className="btn btn-bordered-white mt-4 mt-md-5"
                    onClick={() => this.fetchData()}
                  >
                    {this.state.initData.actionBtn}
                  </a>
                ) : null
              ) : (
                <div className="col-12">
                <ClipLoader color="#36d7b7" size={40} />
              </div>
              )}
              {
                this.state.OpenLoader == false && this.state.data.length == 0 ? 
                "No data found!" : null
              }
              
            </div>
          </div>
        </div>
      </section>
    );
  }
}

export default ProjectTwo;
