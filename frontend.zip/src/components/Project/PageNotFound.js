import React from 'react'

const PageNotFound = () => {
    return (
        <div id="wrapper">
            <h2 className='container text-center'>
                404! Page Not Found!
            </h2>

        </div >
    )
}

export default PageNotFound