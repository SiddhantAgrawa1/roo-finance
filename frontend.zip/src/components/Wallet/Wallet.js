import React, { useEffect, useState } from "react";
import axios from "axios";
import { ChainId, useEthers } from "@usedapp/core";
import WalletConnectProvider from "@walletconnect/web3-provider";
import { DeFiWeb3Connector } from "deficonnect";
import { toast } from 'react-toastify'
import { ethers } from "ethers";
// import * as config from "../config/config";
// import * as utils from "./utils";
// import { IWallet, defaultWallet } from "../store/interfaces";
const BASE_URL =
  "https://my-json-server.typicode.com/themeland/gameon-json-1/wallet";

const Wallet = () => {
  const { activateBrowserWallet, account, activate, deactivate } = useEthers();
  const [data, setData] = useState({});
  const [walletData, setWalletData] = useState([]);
  const [Account, setAccount] = useState(undefined);

  useEffect(() => {
    if(sessionStorage.address){
      setAccount(sessionStorage.address)
    }
  
    axios
      .get(`${BASE_URL}`)
      .then((res) => {
        setData(res.data);
        setWalletData(res.data.walletData);
        
      })
      .catch((err) => console.log(err));
  }, [account]);

  function reloadApp(){
    window.location.reload()
  }

  async function connectToWalletConnect() {
    console.log("WalletConnect");
    try {
      const provider = new WalletConnectProvider({
        qrcode: true,
        bridge: "https://bridge.walletconnect.org",
        rpc: {
          [ChainId.Cronos]: process.env.REACT_APP_CRONOS_RPC,
        },
      });
      await provider.enable();
      await activate(provider);

      const address = await provider.accounts[0]
      
      sessionStorage.setItem("name","walletConnect")
      sessionStorage.setItem("address",address)
      console.log("address : ",address)
      reloadApp()
      // props.onHide()
      // Subscribe to events that reload the app
      provider.on("accountsChanged", connectToWalletConnect);
      provider.on("chainChanged", connectToWalletConnect);
      provider.on("disconnect", disconnectWallet);

      console.log("Trust Wallet Check", provider);
    } catch (error) {
      console.error(error);
    }
  }

  const connectMetaMaskWalletOnClick = async () => {
    try {
      await window.ethereum.request({ method: 'eth_requestAccounts' })
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const address = (await provider.listAccounts())[0]
      const network = await provider.getNetwork()
      sessionStorage.setItem("name","metamask")
      if(network.chainId!==process.env.REACT_APP_NETWORK_ID){
        await addNetwork1()
        await switchNetwork1(ChainId.CronosTestnet)
      }
      sessionStorage.setItem("address",address)
      setAccount(address)
      reloadApp()
      window.ethereum.on('accountsChanged',connectMetaMaskWalletOnClick)
      window.ethereum.on('chainChanged',connectMetaMaskWalletOnClick)
      window.ethereum.on('disconnect',disconnectWallet)

      // window.location.reload()
      console.log(address)
    } catch (e) {
      console.log('errorrrr', e)
    }
  }

  async function switchNetwork1(chainId) {
    let switchNetwork = await new Promise(async (resolve, reject) => {
      let wallet = sessionStorage.getItem('name');
      if (wallet === "metamask") {
        try {
          await this.nativeWindow.ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId: `0x${chainId.toString(16)}` }], // chainId must be in hexadecimal numbers
          });
          resolve('switched Network successfully');
        } catch (error) {
          console.log('Switch Wallet==>', error);
        }
      }
    });

    return switchNetwork;
  }

  async function addNetwork1() {
    const NetworkInfo = {
      "name": "Cronos testnet",
      "explorerLink": "https://testnet.cronoscan.com/",
      "icon": "",
      "bg": "black",
      "symbol": 'CRO',
      "config": {
        method: 'wallet_addEthereumChain',
        params: [{
          chainId: '0x152',
          chainName: 'Cronos',
          nativeCurrency: {
            symbol: 'CRO',
            decimals: 18,
          },
          rpcUrls: ['process.env.REACT_APP_CRONOS_RPC'],
          blockExplorerUrls: ['https://testnet.cronoscan.com/']
        }],
      }
    }
    await this.nativeWindow.ethereum.request(NetworkInfo);
  }
  
  

  async function connectDefiWallet() {
    try {
      const connector = new DeFiWeb3Connector({
        supportedChainIds: [25],
        rpc: {
          [ChainId.Cronos]: process.env.REACT_APP_CRONOS_RPC,
        },
        pollingInterval: 15000,
      });
      await connector.activate();
      window.web3 = connector
      console.log("connect defi ");
      const provider = await connector.getProvider();
      const web3Provider = new ethers.providers.Web3Provider(provider);
      const address = (await web3Provider.listAccounts())[0];
      sessionStorage.setItem('name','defi')
      sessionStorage.setItem('address',address)
      console.log(address)
      setAccount(address);
      window.location.href = '/admin/login'
    } catch (e) {
      console.log(e)
    }
  }

  const disconnectWallet = () => {
     if(!sessionStorage.getItem('address')){
        sessionStorage.clear()
        window.location.reload()
     }
  };

  return (
    <section className="wallet-connect-area">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-12 col-md-8 col-lg-7">
            {/* Intro */}
            <div className="intro text-center">
              <div className="intro-content">
                <span className="intro-text">{data.sub_heading}</span>
                <h3 className="mt-3 mb-0">{data.heading}</h3>
                <p>{data.content}</p>
                <p>{Account !== undefined ? 'Address : '+Account : null}</p>
              </div>
            </div>
          </div>
        </div>
        {Account === undefined ? (
          <>
            <div className="row justify-content-center items">
              <div
                onClick={() => connectMetaMaskWalletOnClick()}
                className="col-12 col-md-6 col-lg-4 item"
              >
                <div className="card single-wallet">
                  <div className="d-block text-center cursor-pointer">
                    <img className="avatar-lg" src="/img/metamask.png" alt="" />
                    <h4 className="mb-0">MetaMask</h4>
                    <p>
                      A browser extension with great flexibility. The web's most
                      popular wallet
                    </p>
                  </div>
                </div>
              </div>
              <div
                onClick={() => connectToWalletConnect()}
                className="col-12 col-md-6 col-lg-4 item"
              >
                <div className="card single-wallet">
                  <div className="d-block text-center cursor-pointer">
                    <img
                      className="avatar-lg"
                      src="/img/walletconnect.png"
                      alt=""
                    />
                    <h4 className="mb-0">WalletConnect</h4>
                    <p>
                      Pair with Trust, Argent, MetaMask & more. Works from any
                      browser, without an extension
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="row justify-content-center items">
              <div
                onClick={() => connectDefiWallet()}
                className="col-12 col-md-6 col-lg-4 item"
              >
                <div className="card single-wallet">
                  <div className="d-block text-center cursor-pointer">
                    <img className="avatar-lg" src="/img/3635.png" alt="" />
                    <h4 className="mb-0">Defi Wallet</h4>
                    <p>
                      Pair with Trust, Argent, MetaMask & more. Works from any
                      browser, without an extension
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
            <div className="row mb-4">
              <div className="col d-flex justify-content-center">
                <button
                  className="btn btn-bordered "
                  onClick={() => disconnectWallet()}
                >
                  Disconnect
                </button>
              </div>
            </div>
          
        )}
      </div>
    </section>
  );
};

export default Wallet;
