import React, { useEffect, useState } from "react";
import axios from "axios";
import { ethers } from "ethers";

import { Modal } from "react-responsive-modal";

import { ChainId, useEthers } from "@usedapp/core";
import WalletConnectProvider from "@walletconnect/web3-provider";
import { DeFiWeb3Connector } from "deficonnect";
import { toast } from "react-toastify";
import {
  ConnectMetaMaskWallet,
  ConnectDefiWallet,
  ConnectToWalletConnect,
} from "../Service/WalletService";

const ConnectWalletModal = (props) => {
  const {
    activateBrowserWallet,
    active,
    account,
    activate,
    deactivate,
    chainId,
    switchNetwork,
  } = useEthers();
  const [Account, setAccount] = useState(undefined);
  const [Defi, setDefi] = useState(false);
  // async function changeNetwork() {
  //   await switchNetwork(ChainId.Cronos)
  // }

  const reloadApp = () => {
    window.location.reload();
  };

  // useEffect(() => {
  //   if (active && chainId != ChainId.Cronos) {
  //     changeNetwork();
  //   }
  // }, [chainId])

  useEffect(() => {
    if (sessionStorage.getItem("address")) {
      setAccount(sessionStorage.getItem("address"));
    }
  }, []);

  const connectMetaMaskWalletOnClick = async () => {
    try {
      await ConnectMetaMaskWallet();
      props.onHide();
    } catch (error) {
      console.log(error);
    }
  };

  const disconnectWallet = () => {
    if (sessionStorage.getItem("address")) {
      sessionStorage.clear();
      window.location.reload();
    }
  };

  async function connectToWalletConnect() {
    try {
      await ConnectToWalletConnect();
      props.onHide();
    } catch (error) {
      console.log(error);
    }
  }

  async function connectDefiWallet() {
    try {
      await ConnectDefiWallet();
      props.onHide();
    } catch (error) {
      console.log(error);
    }
  }

  return (
    <>
      <Modal open={props.open} onClose={props.onHide} center>
        <section className="wallet-connect-area">
          <div className="container">
            <div className="row justify-content-center items">
              <div
                onClick={() => connectMetaMaskWalletOnClick()}
                className="col-12 col-md-6 col-lg-4 item mb-4 mb-lg-0"
              >
                <div className="card single-wallet">
                  <div className="d-block text-center cursor-pointer">
                    <img className="avatar-lg" src="/img/metamask.png" alt="" />
                    <h4 className="mb-0">MetaMask</h4>
                    <p>
                      A browser extension with great flexibility. The web's most
                      popular wallet
                    </p>
                  </div>
                </div>
              </div>
              <div
                onClick={() => connectToWalletConnect()}
                className="col-12 col-md-6 col-lg-4 item mb-4 mb-lg-0"
              >
                <div className="card single-wallet">
                  <div className="d-block text-center cursor-pointer">
                    <img
                      className="avatar-lg"
                      src="/img/walletconnect.png"
                      alt=""
                    />
                    <h4 className="mb-0">WalletConnect</h4>
                    <p>Pair with Defi Wallet, Metamask and more</p>
                  </div>
                </div>
              </div>
              <div
                onClick={() => connectDefiWallet()}
                className="col-12 col-md-6 col-lg-4 item"
              >
                <div className="card single-wallet">
                  <div className="d-block text-center cursor-pointer">
                    <img className="avatar-lg" src="/img/3635.png" alt="" />
                    <h4 className="mb-0">Defi Wallet</h4>
                    <p>
                      Pair with Trust, Argent, MetaMask & more. Works from any
                      browser, without an extension
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </Modal>
    </>
  );
};

export default ConnectWalletModal;
