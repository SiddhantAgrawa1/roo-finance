import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Loader from "../Project/Loader";
import {deployContract} from '../Service/ContractService'
import { ClipLoader } from "react-spinners";

export default function AdminProjects() {
  const [data, setData] = useState([]);
  const navigate = useNavigate();
  const signature = sessionStorage.getItem("signature");
  const address = sessionStorage.getItem("address");
  const username = sessionStorage.getItem("username");
  const [OpenLoader, setLoader] = useState(false);
  const [deleteLoader, setDeleteloader] = useState(false);
  const [DeleteId, setDeleteId] = useState(0);
  const [DataLoader,setDataLoader] = useState(false)
  
  const fetchData = async () => {
    try {
      setDataLoader(true)
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}admin/projects`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ username, address, signature }),
        }
      );
      console.log(response)
      if (response.ok) {
        const data = await response.json();
        setDataLoader(false)
        setData(() => [...data.data]);
      } else {
        setDataLoader(false)
        toast.error(response.statusText)
        navigate("/admin/login");
      }
    } catch (error) {
      setDataLoader(false)
      console.log(error);
      navigate("/admin/login");
    }
  };

  const deleteProject = async (_id) => {
    try {
      if (window.confirm("Are you sure you want to delete this project!") !== true) {
        return
      }
      setDeleteloader(true);
      setDeleteId(_id);
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}admin/deleteProject`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ username, address, signature, _id }),
        }
      );
      console.log("Data", data);
      if (response.status == 200) {
        const Data = await response.json();
        // let updatedData = data.filter((item) => item._id !== _id)
        let index = data.findIndex((item) => item._id == _id);
        data[index].deleteFlag = true;
        console.log("index : ", data[index]);
        setData(data);
        setDeleteloader(false);
        toast.success(Data.message);
      } else {
        console.log("response", response);
        setDeleteloader(false);
        toast.error("Something went wrong");
        // window.location.href = "/admin/login";
      }
    } catch (error) {
      console.log(error);
      setDeleteloader(false);
      toast.error("Something went wrong");
      // window.location.href = "/admin/login";
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const styles = {
    table: {
      border: "1px solid black",
      borderCollapse: "collapse",
      borderColor: "white",
      textAlign: "center",
    },
    th: {
      border: "1px solid black",
      borderCollapse: "collapse",
      borderColor: "white",
      textAlign: "center",
    },
    td: {
      border: "1px solid black",
      borderCollapse: "collapse",
      borderColor: "white",
      textAlign: "center",
    },
  };

  async function deploy(item) {
    try {
      setLoader(true);
      let resp = await deployContract(item)
      setLoader(false)  
      if(resp){
        toast.success("Your contract deployed successfully!");
        window.location.reload()
      }
    } catch (error) {
      setLoader(false);
      console.log(error);
      toast.error("Something went wrong...");
    }
    
  }

  return (
    <>
      <div className="md:container md:mx-auto ">
        <h2 className="form_title text-center">Projects</h2>
        <div className="container">
          <div className="row mb-4">
            <div className="col d-flex justify-content-end">
              <Link to='/admin/form' className="btn">
                Add New
              </Link>
            </div>
          </div>
          {OpenLoader ? <Loader/> : null}
          {DataLoader === false ?  
            data && data.length !== 0 ? (
            <table className="mb-3" style={styles.table}>
              <thead>
                <tr>
                  <th style={styles.th}>No.</th>
                  <th style={styles.th}>Project Name</th>
                  <th style={styles.th}>Contract Address</th>
                  <th style={styles.th}>Nft</th>
                  <th style={styles.th}>Action</th>
                </tr>
              </thead>
              <tbody className="border-separate border-spacing-2 border border-slate-400 ">
                {data.map((item, idx) => (
                  <tr key={idx}>
                    <td style={styles.td}>{idx + 1}</td>
                    <td style={styles.td}>{item.Name_Of_Project}</td>
                    <td style={styles.td}>
                      {item.Contract_Address === ""
                        ? "NULL"
                        : item.Contract_Address}
                    </td>
                    <td style={styles.td}>
                      <img
                        src={`${process.env.REACT_APP_API_URL}${item.imgUrl}`}
                        height="100px"
                        width="100px"
                      ></img>
                    </td>
                    <td style={styles.td}>
                      {item.deleteFlag == 0 ? (
                        deleteLoader === true && DeleteId === item._id ? (
                          <button className="bg-transparent font-semibold py-2 px-4 border text-white mr-2 disabled">
                            Deleting...
                          </button>
                        ) : (
                          <>
                            <button
                              className="bg-transparent font-semibold py-2 px-4 border text-white mr-2"
                              onClick={() =>
                                navigate(
                                  `/admin/updateform/${item.Name_Of_Project}`
                                )
                              }
                            >
                              Edit
                            </button>
                            <button
                              className="bg-transparent font-semibold py-2 px-4 border text-white mr-2"
                              onClick={() => deleteProject(item._id)}
                            >
                              Delete
                            </button>
                            {item.Contract_Address === "" ? (
                              <button
                                className="bg-transparent font-semibold py-2 px-4 border text-white"
                                onClick={() => {
                                  deploy(item);
                                }}
                              >
                                Deploy
                              </button>
                            ) : null}
                          </>
                        )
                      ) : (
                        <button className="bg-transparent font-semibold py-2 px-4 border text-white mr-2 disabled">
                          Deleted
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )  : <div className="col-12 text-center"> No data found! </div> : 
          (
            <div className="col-12   d-flex align-items-center justify-content-center">
            <ClipLoader color="#36d7b7" size={70} />
            </div>
          )}
        </div>
      </div>
    </>
  );
}
