import React, { useEffect, useState } from "react";
import { ethers } from "ethers";
import { useNavigate } from "react-router-dom";
import { ChainId, useEthers } from "@usedapp/core";
import { DeFiWeb3Connector } from "deficonnect";
import Wallet from "../Wallet/Wallet";
import WalletConnectProvider from "@walletconnect/web3-provider";
import { toast } from "react-toastify";
import Loader from "../Project/Loader";
import { GetProvider, addNetork, switchNetwork1 } from "../Service/WalletService";
import ConnectWalletModal from "../Wallet/ConnectWalletModal";

export default function Adminlogin() {
  const { active, account, activate, deactivate, chainId, switchNetwork } =
    useEthers();
  const [OpenLoader, setLoader] = useState(false);
  const [username, setusername] = useState("");
  const [showModal, setShowModal] = useState(true);
  const navigate = useNavigate();
  const [isConnected, setIsConnected] = useState(false);
  
  useEffect(() => {
    if (sessionStorage.getItem("address") !== null) {
      setIsConnected(true);
      setShowModal(false);
    }
  }, [isConnected]);

  const handleSubmit = async () => {
    try {
      if (sessionStorage.getItem("address") !== null) {
        setLoader(true);
        const name = sessionStorage.name;
        let address, signature, provider;
        provider = await GetProvider();
        let network = await provider.getNetwork();

        if (network.chainId != process.env.REACT_APP_NETWORK_ID) {
          return await switchNetwork1(process.env.REACT_APP_NETWORK_ID);
        }
  
        const signer = provider.getSigner();
        address = await signer.getAddress();
        signature = await signer.signMessage(
          `Welcome to roo-finance ${address} ${new Date()
            .toISOString()
            .slice(0, 10)}`
        );

        const resp = await fetch(`${process.env.REACT_APP_API_URL}admin/auth`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ username, address, signature }),
        });
        setLoader(false);
        if (resp.status === 200) {
          sessionStorage.setItem("username", username);
          sessionStorage.setItem("address", address);
          sessionStorage.setItem("signature", signature);
          navigate("/admin/projects");
        } else {
          toast.error(resp.data ? resp.data.message : resp.statusText);
        }
        setLoader(false);
      } else {
        setIsConnected(false);
      }
    } catch (e) {
      setLoader(false);
      console.log(e)
      toast.error(
        e?.reason
          ? e?.reason
          : e.error?.message
          ? e.error?.message
          : e?.message,
        { autoClose: 6000 }
      );
    }
  };

  function handleChange(e) {
    setusername(e.target.value);
  }

  return (
    <>
      {OpenLoader === true ? <Loader /> : null}
      {OpenLoader === false && isConnected === false ? (
        <ConnectWalletModal
          open={showModal}
          onHide={() => setShowModal(false)}
        />
      ) : null}

      <div className="md:container md:mx-auto ">
        <h2 className="form_title text-center">Admin Login</h2>
        <div className="container">
          <div className="row mb-4">
            <div className="col d-flex justify-content-center">
              {isConnected ? (
                <>
                  <input
                    type="text"
                    className="col-3"
                    onChange={(e) => handleChange(e)}
                    placeholder="Username"
                  />
                  <button
                    className="bg-transparent font-semibold py-2 px-4 border text-white btn-b ml-1"
                    onClick={() => handleSubmit()}
                  >
                    Login
                  </button>
                </>
              ) : (
                <button
                  className="bg-transparent font-semibold py-2 px-4 border text-white btn-b ml-1"
                  onClick={() => setShowModal(true)}
                >
                  Connect Wallet
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
