import axios from "axios";
import React, { useState, useEffect } from "react";
import SunEditor from "suneditor-react";
import { Modal } from "react-responsive-modal";
import "suneditor/dist/css/suneditor.min.css";
import { ethers } from "ethers";
import Adminlogin from "./Adminlogin";
import Loader from "../Project/Loader";
import { toast } from "react-toastify";
import { useNavigate } from "react-router";
import { deployContract } from "../Service/ContractService";

const AdminForm = () => {
  const signature = sessionStorage.getItem("signature");
  const address = sessionStorage.getItem("address");
  const username = sessionStorage.getItem("username");
  const [isLogin, setisLogin] = useState(undefined);
  const [openModal, setOpenModal] = useState(false);
  const [OpenLoader, setLoader] = useState(false);
  const navigate = useNavigate();

  const validateAdmin = async () => {
    try {
      const resp = await fetch(`${process.env.REACT_APP_API_URL}admin/auth`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, address, signature }),
      });
      if (resp.status === 200) setisLogin(true);
      else if (resp.status === 401) {
        setisLogin(false);
        toast.error(resp.statusText);
        navigate("/admin/login");
      }
    } catch (e) {
      toast.error(
        e?.reason
          ? e?.reason
          : e.error?.message
          ? e.error?.message
          : e?.message,
        { autoClose: 6000 }
      );
      navigate("/admin/login");
    }
  };

  useEffect(() => {
    validateAdmin();
  }, []);

  const validate = () => {
    let valid = true;
    console.log(contents);

    if (
      contents.Name_Of_Project === false ||
      contents.Name_Of_Project.trim().length < 2 ||
      contents.Name_Of_Project.trim().length > 100 ||
      !/^[a-zA-Z]+/.test(contents.Name_Of_Project)
    ) {
      setcontents((data) => ({ ...data, Name_Of_Project: false }));
      valid = false;
    }

    if (
      contents.Amount_of_supply === false ||
      contents.Amount_of_supply == "" ||
      contents.Amount_of_supply <= 0
    ) {
      setcontents((data) => ({ ...data, Amount_of_supply: false }));
      valid = false;
    }
    if (
      contents.Price_of_collection == "" ||
      contents.Price_of_collection <= 0
    ) {
      setcontents((data) => ({ ...data, Price_of_collection: false }));
      valid = false;
    }
    if (!ethers.utils.isAddress(contents.Project_Owner)) {
      setcontents((data) => ({ ...data, Project_Owner: false }));
      valid = false;
    }
    if (
      contents.Token_Name === false ||
      contents.Token_Name.trim().length < 2 ||
      contents.Token_Name.trim().length > 100 ||
      !/^[a-zA-Z]+/.test(contents.Token_Name)
    ) {
      setcontents((data) => ({ ...data, Token_Name: false }));
      valid = false;
    }
    if (
      contents.Limit_per_NFT === false ||
      contents.Limit_per_NFT == "" ||
      contents.Limit_per_NFT <= -1
    ) {
      setcontents((data) => ({ ...data, Limit_per_NFT: false }));
      valid = false;
    }
    if (
      contents.WL_Amount === false ||
      contents.WL_Amount == "" ||
      contents.WL_Amount <= -1
    ) {
      setcontents((data) => ({ ...data, WL_Amount: false }));
      valid = false;
    }
    if (
      contents.IPFS_information === false ||
      contents.IPFS_information.trim().length < 2 ||
      contents.IPFS_information.trim().length > 100 ||
      !/^[a-zA-Z]+/.test(contents.IPFS_information)
    ) {
      valid = false;
      setcontents((data) => ({ ...data, IPFS_information: false }));
    }
    if (
      contents.Token_symbol === false ||
      contents.Token_symbol.trim().length < 1 ||
      contents.Token_symbol.trim().length > 50
    ) {
      valid = false;
      setcontents((data) => ({ ...data, Token_symbol: false }));
    }
    if (image === false || image === "") {
      valid = false;
      setcontents((data) => ({ ...data, Picture_of_Collection: false }));
    }
    if (
      contents.Project_Summary === false ||
      contents.Project_Summary.trim().length < 2
    ) {
      valid = false;
      setcontents((data) => ({ ...data, Project_Summary: false }));
    }
    if (
      contents.Video === false ||
      (contents.Video.trim() !== "" &&
        !/^https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/=]*)$/.test(
          contents.Video
        ))
    ) {
      valid = false;
      setcontents((data) => ({ ...data, Video: false }));
    }
    // if (contents.Distribution.trim().length < 2) {
    //   valid = false;
    //   setcontents((data) => ({ ...data, Distribution: false }));
    // }
    if (
      contents.Project_Overview === false ||
      contents.Project_Overview.trim().length < 2
    ) {
      valid = false;
      setcontents((data) => ({ ...data, Project_Overview: false }));
    }
    if (
      contents.Roadmap_Summary === false ||
      contents.Roadmap_Summary.trim().length < 2
    ) {
      valid = false;
      setcontents((data) => ({ ...data, Roadmap_Summary: false }));
    }
    if (
      contents.Discord_Link === false ||
      (contents.Discord_Link.trim() != "" &&
        !/^(https?:\/\/)?(www\.)?(discord\.(gg|io|me|li)|discordapp\.com\/invite)\/.+[a-z]/.test(
          contents.Discord_Link
        ))
    ) {
      valid = false;
      setcontents((data) => ({ ...data, Discord_Link: false }));
    }
    if (
      contents.Twitter_Link === false ||
      (contents.Twitter_Link.trim() != "" &&
        !/http(?:s)?:\/\/(?:www\.)?twitter\.com\/([a-zA-Z0-9_]+)/.test(
          contents.Twitter_Link
        ))
    ) {
      valid = false;
      setcontents((data) => ({ ...data, Twitter_Link: false }));
    }
    if (
      contents.Telegram_Link === false ||
      (contents.Telegram_Link.trim() != "" &&
        !/^(https?\:\/\/)?((www\.)?t\.me)\/.+$/.test(contents.Telegram_Link))
    ) {
      valid = false;
      setcontents((data) => ({ ...data, Telegram_Link: false }));
    }
    if (
      contents.Website === false ||
      (contents.Website.trim() != "" &&
        !/^https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/=]*)$/.test(
          contents.Website
        ))
    ) {
      valid = false;
      setcontents((data) => ({ ...data, Website: false }));
    }
    if (
      contents.Date_of_Launch === false ||
      contents.Date_of_Launch == "" ||
      new Date(contents.Date_of_Launch) < new Date()
    ) {
      valid = false;
      setcontents((data) => ({ ...data, Date_of_Launch: false }));
    } else {
      setcontents((data) => ({
        ...data,
        Date_of_Launch: new Date(data.Date_of_Launch).toUTCString(),
      }));
    }

    if (contents.Duration === false || contents.Duration == "") {
      valid = false;
      setcontents((data) => ({ ...data, Duration: false }));
    }
    // debugger
    if (contents.WL_List !== "" && contents.WL_List.length > 0) {
      let wl_list = contents.WL_List.toString().split(",");
      let isCorrect = true;
      for (let user of wl_list) {
        if (!ethers.utils.isAddress(user)) {
          valid = false;
          isCorrect = false;
          setcontents((data) => ({ ...data, WL_List: false }));
        }
      }
      if (isCorrect !== false)
        setcontents((data) => ({ ...data, WL_List: [...wl_list] }));
    } else {
      setcontents((data) => ({ ...data, WL_List: [] }));
    }
    return valid;
  };

  const [image, setImage] = useState("");
  const [contents, setcontents] = useState({
    Name_Of_Project: "",
    Amount_of_supply: "",
    IPFS_information: "",
    Price_of_collection: "",
    Token_symbol: "",
    Limit_per_NFT: "",
    WL_List: [],
    Project_Summary: "",
    Video: "",
    Project_Overview: "",
    // Distribution: "",
    WL_Amount: "",
    Roadmap_Summary: "",
    Discord_Link: "",
    Twitter_Link: "",
    Telegram_Link: "",
    Website: "",
    Date_of_Launch: "",
    Project_Owner: "",
    Token_Name: "",
    Duration: 3600,
  });
  const [Duration, setDuration] = useState(1);

  const options = {
    buttonList: [
      ["undo", "redo"],
      ["font", "fontSize", "formatBlock"],
      ["bold", "underline", "italic", "strike", "subscript", "superscript"],
      ["fontColor", "hiliteColor", "textStyle"],
      ["removeFormat"],
      ["outdent", "indent"],
      ["align", "horizontalRule", "list", "lineHeight"],
      ["table", "link", "image", "video"],
      ["imageGallery", "fullScreen"],
    ],
  };

  async function deploy() {
    try {
      setOpenModal(false);
      setLoader(true);
      let res = await deployContract(contents);
      setLoader(false);
      if (res) {
        toast.success("Your contract deployed successfully!");
      }
      navigate("/admin/projects");
    } catch (error) {
      setOpenModal(false);
      setLoader(false);
      console.log(error);
      toast.error("Something went wrong...");
    }
  }

  const handleSubmit = async (event) => {
    setLoader(true);
    try {
      event.preventDefault();
      if (validate()) {
        // debugger
        let content = contents;
        // content.Date_of_Launch  = new Date(content.Date_of_Launch).toUTCString()
        content.Date_of_Launch =
          new Date(content.Date_of_Launch).getTime() / 1000;

        // if(content.WL_List === "")
        const formData = new FormData();
        formData.append("image", image);
        formData.append("data", JSON.stringify(content));
        await axios
          .post(`${process.env.REACT_APP_API_URL}admin/form`, formData)
          .then((res) => {
            setLoader(false);
            setOpenModal(true);
          })
          .catch((e) => {
            setLoader(false);
            console.log(e);
            setOpenModal(false);
            toast.error(
              e.response?.data ? e.response?.data.message : e?.message
            );
          });
      } else {
        setLoader(false);
        toast("Please fill the field properly", { autoClose: 6000 });
      }
      setLoader(false);
      // setOpenModal(true);
    } catch (e) {
      console.log(e);
      setLoader(false);
      toast.error(e?.statusText);
    }
  };

  const onChangeEvent = (event, id1) => {
    let id, value;
    if (id1 === "Project_Overview") {
      id = id1;
      value = event;
    } else if (id1 === "Roadmap_Summary") {
      id = id1;
      value = event;
    } else if (event.target.id == "Price_of_collection") {
      id = event.target.id;
      value = (parseFloat(event.target.value) * 1000000000000000000).toString();
      console.log(value);
    } else if (event.target.id == "WL_Amount") {
      id = event.target.id;
      value = (parseFloat(event.target.value) * 1000000000000000000).toString();
      console.log(value);
    } else if (event.target.id == "Duration") {
      id = event.target.id;
      value =
        parseFloat(event.target.value) > 0 !== false
          ? event.target.value.toString()
          : "";
      value *= 3600;
      event.target.value > 0
        ? setDuration(event.target.value)
        : setDuration("");
    } else {
      console.log(event.target.valid);
      id = event.target.id;
      value = event.target.value;
    }
    setcontents((data) => ({ ...data, [id]: value }));
  };

  return (
    <>
      <>
        {OpenLoader === true ? <Loader /> : null}
        {
          <Modal
            open={openModal}
            styles={{
              closeButton: { display: "none" },
              modal: {
                height: "auto", // set height to auto to allow content to adjust
                maxWidth: "90vw", // set a max width to prevent modal from overflowing on small screens
                overflow: "hidden",
              },
              overlay: {
                backgroundColor: "rgba(0, 0, 0, 0.5)", // darken the overlay to increase contrast
              },
            }}
            center
            onOverlayClick={(e) => e.preventDefault()}
          >
            <div>
              <div>
                <h4>Deploy your contract now</h4>
                <button
                  className="bg-transparent font-semibold py-2 px-4 text-center border text-white btn-b ml-1 float-right"
                  onClick={async () => await deploy()}
                >
                  Deploy
                </button>
              </div>
            </div>
          </Modal>
        }
      </>
      {isLogin === undefined ? (
        <Loader />
      ) : isLogin === true ? (
        <div className="md:container md:mx-auto ">
          <form action="/">
            <h2 className="form_title text-center">Admin Form</h2>
            <div className="container">
              <div className="row mx-3 my-3">
                <div className="col-md-6">
                  <label htmlFor="Name_Of_Project">Name of Project</label>
                  <input
                    type="text"
                    id="Name_Of_Project"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Name_Of_Project === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid name of project
                    </p>
                  ) : null}
                </div>
                <div className="col-md-6 mt-2 mt-md-0">
                  <label htmlFor="Amount_of_supply">Amount of supply</label>
                  <input
                    type="number"
                    id="Amount_of_supply"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Amount_of_supply === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid amount of supply
                    </p>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="container">
              <div className="row  mx-3 my-2">
                <div className="col-md-6">
                  <label htmlFor="IPFS_information">IPFS URL</label>
                  <input
                    type="url"
                    id="IPFS_information"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.IPFS_information === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid IPFS information
                    </p>
                  ) : null}
                </div>
                <div className="col-md-6">
                  <label htmlFor="Price_of_collection">
                    Price of collection
                  </label>
                  <input
                    type="number"
                    id="Price_of_collection"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Price_of_collection === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid price of collection
                    </p>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="container">
              <div className="row  mx-3 my-3">
                <div className="col-md-6">
                  <label htmlFor="Project_Owner">Project Owner</label>
                  <input
                    type="text"
                    id="Project_Owner"
                    maxLength="100"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Project_Owner === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid Project Owner
                    </p>
                  ) : null}
                </div>
                <div className="col-md-6">
                  <label htmlFor="Token_Name">Token Name</label>
                  <input
                    type="text"
                    id="Token_Name"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Token_Name === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid Token Name
                    </p>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="container">
              <div className="row  mx-3 my-3">
                <div className="col-md-6">
                  <label htmlFor="Token_symbol">Token symbol</label>
                  <input
                    type="text"
                    id="Token_symbol"
                    maxLength="100"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Token_symbol === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid Token symbol
                    </p>
                  ) : null}
                </div>
                <div className="col-md-3">
                  <label htmlFor="Limit_per_NFT">Limit per NFT</label>
                  <input
                    type="number"
                    id="Limit_per_NFT"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Limit_per_NFT === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid Limit Per NFT
                    </p>
                  ) : null}
                </div>
                <div className="col-md-3">
                  <label htmlFor="WLList">WL Amount</label>
                  <input
                    type="number"
                    id="WL_Amount"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.WL_Amount === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid WL Amount
                    </p>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="container">
              <div className="row  mx-3 my-3">
                <div className="col-md-6">
                  <label htmlFor="WL_List">WL List</label>
                  <input
                    type="text"
                    id="WL_List"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.WL_List === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid wallet address
                    </p>
                  ) : null}
                </div>
                <div className="col-md-6">
                  <label htmlFor="Project_Summary">Project Summary</label>
                  <input
                    type="text"
                    id="Project_Summary"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Project_Summary === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid project summary
                    </p>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="container">
              <div className="row  mx-3 my-0">
                <div className="col-md-6">
                  <label htmlFor="Picture_of_Collection">
                    Picture of Collection
                  </label>
                  <input
                    type="file"
                    id="image"
                    accept="image/*"
                    className="form-control-file"
                    onChange={(e) => setImage(e.target.files[0])}
                  />
                  {contents.Picture_of_Collection === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Image is required
                    </p>
                  ) : null}
                </div>
                <div className="col-md-6">
                  <label htmlFor="Video">Video</label>
                  <input
                    type="url"
                    id="Video"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Video === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid video url
                    </p>
                  ) : null}
                </div>

                {/* <div className="col-md-6">
                  <label htmlFor="Distribution">Distribution</label>
                  <input
                    type="url"
                    id="Distribution"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Distribution === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      
                      Enter valid distribution
                    </p>
                  ) : null}
                </div> */}
              </div>
            </div>
            <div className="container">
              <div className="row  mx-3 my-0">
                <div className="col-md-6">
                  <label htmlFor="Project_Overview">Project Overview</label>
                  <SunEditor
                    id="Project_Overview"
                    onChange={(e) => onChangeEvent(e, "Project_Overview")}
                    setOptions={options}
                  />
                  {contents.Project_Overview === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid project overview
                    </p>
                  ) : null}
                </div>
                <div className="col-md-6">
                  <label htmlFor="Roadmap_Summary">Roadmap Summary</label>
                  <SunEditor
                    id="Roadmap_Summary"
                    onChange={(e) => onChangeEvent(e, "Roadmap_Summary")}
                    setOptions={options}
                  />
                  {contents.Roadmap_Summary === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid roadmap summary
                    </p>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="container">
              <div className="row  mx-3 my-3">
                <div className="col-md-6">
                  <label htmlFor="Discord_Link">Discord Link</label>
                  <input
                    id="Discord_Link"
                    type="url"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Discord_Link === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid discord url
                    </p>
                  ) : null}
                </div>
                <div className="col-md-6">
                  <label htmlFor="Twitter_Link">Twitter Link</label>
                  <input
                    id="Twitter_Link"
                    type="url"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Twitter_Link === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid twitter link
                    </p>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="container">
              <div className="row  mx-3 my-3">
                <div className="col-md-6">
                  <label htmlFor="Telegram_Link">Telegram Link</label>
                  <input
                    id="Telegram_Link"
                    type="url"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Telegram_Link === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid telegram link
                    </p>
                  ) : null}
                </div>
                <div className="col-md-6">
                  <label htmlFor="Website">Website</label>
                  <input
                    id="Website"
                    type="url"
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Website === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid website url
                    </p>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="container">
              <div className="row  mx-3 my-4">
                <div className="col-md-6">
                  <label htmlFor="Date_of_Launch">Date of Launch</label>
                  <input
                    id="Date_of_Launch"
                    type="datetime-local"
                    style={{
                      // width: "60%",
                      maxWidth: "50vw",
                      padding: "10px",
                      boxSizing: "border-box",
                    }}
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Date_of_Launch === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid date of launch
                    </p>
                  ) : null}
                </div>

                <div className="col-md-6">
                  <label htmlFor="Duration">Duration(Days)</label>
                  <input
                    id="Duration"
                    type="number"
                    style={{
                      width: "60%",
                      maxWidth: "50vw",
                      padding: "10px",
                      boxSizing: "border-box",
                    }}
                    defaultValue="1"
                    value={Duration}
                    className="form-control"
                    onChange={(e) => onChangeEvent(e)}
                  />
                  {contents.Duration === false ? (
                    <p style={{ color: "red", margin: "0px" }}>
                      Enter valid Duration
                    </p>
                  ) : null}
                </div>
              </div>
              <div className="row mb-4">
                <div className="col d-flex justify-content-center">
                  <button
                    className="btn btn-bordered "
                    onClick={(e) => handleSubmit(e)}
                  >
                    Submit
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      ) : (
        <Adminlogin />
      )}
    </>
  );
};

export default AdminForm;
