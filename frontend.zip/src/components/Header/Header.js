import React, { useState , useEffect} from "react";
import { ChainId, useEthers } from "@usedapp/core";
import {Link} from "react-router-dom";

import ConnectWalletModal from "../Wallet/ConnectWalletModal";

const Header = () => {
  const [showModal, setShowModal] = useState(false);
  const { account, activate, deactivate } = useEthers();
  const [Account,setAccount] = useState(undefined)

  useEffect(async () => {
    if (sessionStorage.getItem("address")) {
      setAccount(sessionStorage.getItem('address'))
      setShowModal(false)
    }
  },[])


  const disconnectWallet = () => {
    deactivate();
    sessionStorage.clear()
    setAccount(undefined)
    window.location.reload()
  };
  return (
    <>
      <header id="header">
        {/* Navbar */}
        <nav
          data-aos="zoom-out"
          data-aos-delay={800}
          className="navbar gameon-navbar navbar-expand"
        >
          <div className="container header">
            {/* Logo */}
            <Link to="/" className="navbar-brand" >
              <img src="\img/Roo.png" alt="Roo Finance" />
            </Link>
            <div className="ml-auto" />
            <ul className="navbar-nav items mx-auto">
              <li className="nav-item">
                <Link to="/" className="nav-link">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/projects" className="nav-link">
                  Projects
                </Link>
              </li>
              <li className="nav-item">
                <a href="https://staking.roo.finance" className="nav-link" target="_blank">
                  Staking
                </a>
              </li>
              <li className="nav-item">
                <a href="https://roofinance.netlify.app/Pesky-Kanga" className="nav-link">
                Rebel Kanga Mint
                </a>
              </li>
            </ul>

            {/* Navbar Icons */}
            <ul className="navbar-nav icons">
              <li className="nav-item">
                <Link
                  href="#"
                  className="nav-link"
                  data-toggle="modal"
                  data-target="#search"
                >
                  <i className="icon-magnifier" />
                </Link>
              </li>
            </ul>
            {/* Navbar Toggler */}
            <ul className="navbar-nav toggle">
              <li className="nav-item">
                <Link
                  href="#"
                  className="nav-link"
                  data-toggle="modal"
                  data-target="#menu"
                >
                  <i className="icon-menu m-0" />
                </Link>
              </li>
            </ul>
            {/* Navbar Action Button */}
            <ul className="navbar-nav action">
              {!Account && (
                <li
                  className="nav-item ml-2"
                  onClick={() => setShowModal(true)}
                >
                  <p className="custom-border">Wallet Connect</p>
                  {/* <div className="btn ml-lg-auto btn-bordered-white"><i className="icon-wallet mr-md-2" />Wallet Connect</div> */}
                </li>
              )}
              {Account && (
                <li
                  className="nav-item ml-2"
                  onClick={() => disconnectWallet()}
                >
                  <p className="custom-border">
                    {Account.substring(0, 5)}...{Account.substring(39, 42)} |
                    Disconnect
                  </p>
                  {/* <div className="btn ml-lg-auto btn-bordered-white">
                                            <i className="icon-logout mr-md-2" />
                                        </div> */}
                </li>
              )}
            </ul>
          </div>
        </nav>
      </header>
      {showModal && (
        <ConnectWalletModal
          open={showModal}
          onHide={() => setShowModal(false)}
        />
      )}
    </>
  );
};

export default Header;
