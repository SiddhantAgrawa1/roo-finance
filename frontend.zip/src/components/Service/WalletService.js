import React, { useEffect, useState } from "react";
import { ChainId, useEthers } from "@usedapp/core";
import { DeFiWeb3Connector } from "deficonnect";
import WalletConnectProvider from "@walletconnect/web3-provider";
import { ethers } from "ethers";
import { toast } from "react-toastify";

export const GetProvider = async () => {
  // const {activate} = useEthers();
  try {
    let provider, signer;
    if (sessionStorage.address) {
      const name = sessionStorage.name;
      if (name === "metamask") {
        provider = await new ethers.providers.Web3Provider(window.ethereum);
        signer = provider.getSigner();
      } else if (name === "defi") {
        const connector = new DeFiWeb3Connector({
          supportedChainIds: [process.env.REACT_APP_NETWORK_ID],
          rpc: {
            [process.env.REACT_APP_NETWORK_ID]:
              process.env.REACT_APP_CRONOS_RPC,
          },
        });
        await connector.activate();
        console.log("connect defi ");
        const provider1 = await connector.getProvider();
        provider = await new ethers.providers.Web3Provider(provider1);
        signer = provider.getSigner();
      } else if (name === "walletConnect") {
        console.log("wallet connect");
        const provider1 = new WalletConnectProvider({
          qrcode: true,
          bridge: "https://bridge.walletconnect.org",
          rpc: {
            [process.env.REACT_APP_NETWORK_ID]:
              process.env.REACT_APP_CRONOS_RPC,
          },
          chainId: process.env.REACT_APP_NETWORK_ID,
        });
        await provider1.enable();
        // await activate(provider);
        // if (!(provider.chainId === 25)) {
        //   await switchNetwork(ChainId.Cronos)
        // }
        // const provider1 = await connector.getProvider();
        provider = await new ethers.providers.Web3Provider(provider1);
        signer = await provider.getSigner();
      }
    }
    return provider;
  } catch (error) {
    console.log("Provider Error : ", error);
    throw error
  }
};

let provider;
export const ConnectMetaMaskWallet = async () => {
  try {
    await window.ethereum.request({ method: "eth_requestAccounts" });
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const address = (await provider.listAccounts())[0];
    const network = await provider.getNetwork();
    if (network.chainId != process.env.REACT_APP_NETWORK_ID) {
      await switchNetwork1("metamask");
    }
    sessionStorage.setItem("name", "metamask");
    sessionStorage.setItem("address", address);
    toast.success("Your wallet connected successfully!");
    window.location.reload();
  } catch (e) {
    console.log("wallet error", e);
    toast.error(
      e?.reason
        ? e?.reason
        : e.error?.message
        ? e.error?.message
        : e?.message,
        { autoClose: 6000 }
        );
  }
};

export async function switchNetwork1(wallet) {
  // debugger
  let chainId = parseInt(process.env.REACT_APP_NETWORK_ID);
  // debugger
  try {
    if (wallet === "metamask") {
      if(window.ethereum){
      await window.ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: `0x${chainId.toString(16)}` }], // chainId must be in hexadecimal numbers
      });
    }else{
      throw new Error("Wallet not found!")
    }
    } else if (wallet == "walletConnect") {
      if(provider.request){
      await provider.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: `0x${chainId.toString(16)}` }], // chainId must be in hexadecimal numbers
      });
    }else{
      throw new Error("Wallet not found!")
    }
    } else if (wallet == "defi") {
      toast.error("Wrong network detected")
      // await this.nativeWindow.ethereum.request(NetworkInfo);
      // console.log(provider)
      // await provider.request({
      //   method: "wallet_switchEthereumChain",
      //   params: [{ chainId: `0x${chainId.toString(16)}` }], // chainId must be in hexadecimal numbers
      // });
    }
  } catch (error) {
    throw error
  }
}

export async function addNetork() {
  try {
    // const NetworkInfo = {
    //   name: "Cronos testnet",
    //   explorerLink: "https://testnet.cronoscan.com/",
    //   icon: "",
    //   bg: "black",
    //   symbol: "CRO",
    //   config: {
    //     method: "wallet_addEthereumChain",
    //     params: [
    //       {
    //         chainId: "0x152",
    //         chainName: "Cronos",
    //         nativeCurrency: {
    //           symbol: "CRO",
    //           decimals: 18,
    //         },
    //         rpcUrls: [process.env.REACT_APP_CRONOS_RPC],
    //         blockExplorerUrls: ["https://testnet.cronoscan.com/"],
    //       },
    //     ],
    //   },
    // };
    // debugger
    const NetworkInfo = {
      name: "Mumbai",
      explorerLink: "https://rpc-mumbai.maticvigil.com",
      icon: "",
      bg: "black",
      symbol: "MATIC",
      config: {
        method: "wallet_addEthereumChain",
        params: [
          {
            chainId: "0x13881",
            chainName: "Cronos",
            nativeCurrency: {
              symbol: "CRO",
              decimals: 18,
            },
            rpcUrls: ["https://rpc-mumbai.maticvigil.com"],
            blockExplorerUrls: ["https://mumbai.polygonscan.com"],
          },
        ],
      },
    };

    const wallet = sessionStorage.getItem("name");
    if (wallet === "metamask") {
      await window.ethereum.request(NetworkInfo.config);
    } else if (wallet === "walletConnect") {
      await provider.request(NetworkInfo.config);
      await provider.request({
        method: "wallet_switchEthereumChain",
        params: [
          { chainId: `0x${process.env.REACT_APP_NETWORK_ID.toString(16)}` },
        ], // chainId must be in hexadecimal numbers
      });
    } else if (wallet === "defi") {
      // await window.ethereum.request(NetworkInfo.config);  
      await this.nativeWindow.ethereum.request(NetworkInfo);
    }
  } catch (error) {
    console.log("Switch Wallet==>", error);
    throw error;
  }
}

export const disconnectWallet = () => {
  // debugger;
  sessionStorage.clear();
  window.location.reload();
};

export async function ConnectToWalletConnect() {
  try {
    // debugger;
    sessionStorage.clear();
    provider = new WalletConnectProvider({
      qrcode: true,
      bridge: "https://bridge.walletconnect.org",
      rpc: {
        [process.env.REACT_APP_NETWORK_ID]: process.env.REACT_APP_CRONOS_RPC,
      },
    });
    await provider.enable();
    console.log(provider)
    if (provider.chainId != process.env.REACT_APP_NETWORK_ID) {
      await switchNetwork1("walletConnect")
    }
    const address = await provider.accounts[0];
    sessionStorage.setItem("name", "walletConnect");
    sessionStorage.setItem("address", address);
    toast.success("Your wallet connected successfully!");
    window.location.reload();
  } catch (error) {
    console.error(error);
    toast.error(error?.message);
  }
}

export async function ConnectDefiWallet() {
  try {
    // debugger;
    sessionStorage.clear();
    const connector = new DeFiWeb3Connector({
      supportedChainIds: [process.env.REACT_APP_NETWORK_ID],
      rpc: {
        [process.env.REACT_APP_NETWORK_ID]: process.env.REACT_APP_CRONOS_RPC,
      },
      pollingInterval: 15000,
    });
    //   console.log("connector", connector);
    await connector.activate();
    let provider1 = await connector.getProvider();
    provider = await new ethers.providers.Web3Provider(provider1);
    console.log(parseInt(provider1.chainId,16))
    console.log(process.env.REACT_APP_NETWORK_ID)
    if(parseInt(provider1.chainId,16) != process.env.REACT_APP_NETWORK_ID){
      toast.error("Wrong network detected")
      return
    }
    const address = (await provider.listAccounts())[0];
    sessionStorage.setItem("name", "defi");
    sessionStorage.setItem("address", address);
    toast.success("Your wallet connected successfully!");
    window.location.reload();
  } catch (error) {
    console.error(error);
  }
}
