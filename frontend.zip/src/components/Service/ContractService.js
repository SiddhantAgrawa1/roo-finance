import { GetProvider, switchNetwork1 } from "./WalletService";
import { toast } from "react-toastify";
import { ethers } from "ethers";
import { ChainId } from "@usedapp/core";
import { Convert } from "../Project/ConvertMintPrice";
const abi = require("../ContractData/bsc.json");
const bytecode = require("../ContractData/bytecode.json");

export const fetchContractDetails = async (data) => {
  try {
    const provider = new ethers.providers.JsonRpcProvider(
      process.env.REACT_APP_CRONOS_RPC
    );
    // const ,response = await fetch('https://coincodex.com/api/coincodex/get_coin/cro');
    // if(response.status !== 200){
    //   throw new Error(response.statusText)
    // }
    // const usdData = await response.json();
    const usdData = 0.0007;
    let projects = [];
    for (let project of data) {
      let contractAddress = project.Contract_Address;
      const contract = new ethers.Contract(contractAddress, abi, provider);
      const mintPrice = await contract.mintPrice();
      const maxMintSupply = await contract.maxMintSupply();
      const totalSupply = await contract.totalSupply();
      const value = ((mintPrice / 1e18)*usdData.last_price_usd).toFixed(4);
      let price = {
        mintPrice: mintPrice / 1e18,
        MaxSupply: parseInt(maxMintSupply._hex, 16),
        totalSupply: parseInt(totalSupply, 16),
        value: 0.0007,
      };
      projects.push({ ...project, ...price });
    }
    return projects;
  } catch (e) {
    console.log(e);
    toast.error(
      e.data.message ? e.data.message : e?.message ? e?.message : e?.resoan,
      { autoClose: 6000 }
    );
  }
};

export const deployContract = async (item) => {
  try {
    // debugger
    let provider, signer, network;
    provider = await GetProvider();
    network = await provider.getNetwork();
    if (network.chainId != process.env.REACT_APP_NETWORK_ID) {
      await switchNetwork1();
      // await addNetork();
      provider = await GetProvider();
      network = await provider.getNetwork();
    }
    if (network.chainId == process.env.REACT_APP_NETWORK_ID) {
      signer = await provider.getSigner();

      const factory = new ethers.ContractFactory(abi, bytecode, signer);
      let wl_list = item.WL_List;

      const contract = await factory.deploy(
        item.IPFS_information.toString(),
        item.Amount_of_supply.toString(), // maxMintSupply,
        item.Price_of_collection.toString(), // mintPrice,
        item.Limit_per_NFT.toString(), // maxUserMintAmount,
        item.Project_Owner.toString(), //address projectOwner
        item.Duration.toString(),
        item.Token_Name.toString(),
        item.Token_symbol.toString(),
        wl_list,
        Math.floor(new Date(item.Date_of_Launch).getTime() / 1000),
        item.WL_Amount.toString()
      );

      var deployAddress = await contract.deployed();
      const resp = await fetch(
        `${process.env.REACT_APP_API_URL}admin/contractAddress`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            address: deployAddress.address,
            projectName: item.Name_Of_Project,
            Token_Name: item.Token_Name,
          }),
        }
      );
      if(resp.status == 200){
        return true
      }
      else {
        toast.error(resp?.message, { autoClose: 6000 });
        return false
      }
    } else {
      toast.error("User connected to wrong network!");
      return false
    }
  } catch (e) {
    console.log(e);
    toast.error(
      e?.reason ? e?.reason : e.error?.message ? e.error?.message : e?.message,
      { autoClose: 6000 }
    );
    return false
  }
};
