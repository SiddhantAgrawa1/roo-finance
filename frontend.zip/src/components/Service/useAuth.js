import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router';
import { toast } from 'react-toastify';
import { Navigate } from "react-router-dom";

function useAuth() {
    const [auth,setAuth] = useState(false)
    const signature = sessionStorage.getItem("signature");
    const address = sessionStorage.getItem("address");
    const username = sessionStorage.getItem("username");
    debugger

    const Authentication = async() => {
        debugger
        try {
          const resp = await fetch(`${process.env.REACT_APP_API_URL}admin/auth`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ username, address, signature }),
          });
          console.log(resp)
          if(resp.ok){
              setAuth(true)
              return true
          }else{
            setAuth(false)
            toast.error(resp.statusText)
            console.log(resp.statusText)
            return false
          }
        } catch (error) {
            console.log(error)
          setAuth(false)
          return false
        }
      }

    useEffect(() => {
         Authentication()
      }, []);

  return {
    auth
  }
}

export default useAuth