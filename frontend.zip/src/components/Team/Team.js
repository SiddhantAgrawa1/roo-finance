import React, { Component } from 'react';

const initData = {
    sub_heading: "Creative",
    heading: "Our Team",
    btn: "View Team"
}

const data = [
    {
        id: "1",
        img: "/img/joey.jpg",
        name: "Joey",
        designation: "Community Lead",
        socialProfile: "https://twitter.com/Cronos_Joey"
    },
    {
        id: "2",
        img: "/img/team_2.png",
        name: "F17K20",
        designation: "Advisor/Admin",
        socialProfile: "https://twitter.com/asdaidalos"
    },
    {
        id: "3",
        img: "/img/team_3.png",
        name: "Lil Tim",
        designation: "Discord Boss",
        socialProfile: "ttps://twitter.com/RooFinance"
    },
    {
        id: "4",
        img: "/img/team_4.png",
        name: "Luan",
        designation: "Artist",
        socialProfile: "https://twitter.com/RooFinance"
    },
    
]


const socialData = [
    {
        id: "1",
        link: "https://twitter.com/RooFinance",
        icon: "fab fa-twitter"
    },
    {
        id: "2",
        link: "https://t.me/Roo_finance",
        icon: "fab fa-telegram"
    },
    {
        id: "3",
        link: "https://www.facebook.com/profile.php?id=100087503031319",
        icon: "fas fa-globe"
    },
    {
        id: "4",
        link: "https://discord.gg/4u5muHcdaJ",
        icon: "fab fa-discord"
    }
]

class Team extends Component {
    state = {
        initData: {},
        data: [],
        socialData: []
    }
    getSocialData(name) {
        let socialProfile = null;
        this.state.data.forEach(function(item) {
          if (item.name === name) {
            socialProfile = item.socialProfile;
          }
        });
        return socialProfile;
      }
      
    componentDidMount(){
        this.setState({
            initData: initData,
            data: data,
            socialData: socialData
        });
    }
    render() {
    return (
        <section className="team-area p-0">
            <div className="container">
                <div className="row">
                    <div className="col-12">
                        {/* Intro */}
                        <div className="intro d-flex justify-content-between align-items-end m-0">
                        <div className="intro-content">
                            <span className="intro-text">Creative</span>
                            <h3 className="mt-3 mb-0">Our Team</h3>
                        </div>
                        <div className="intro-btn">
                            <a className="btn content-btn" href="https://medium.com/@KangaDegens/team-of-roo-finance-6aab1398712">View Team</a>
                        </div>
                        </div>
                    </div>
                </div>
                <div className="team-slides">
                    <div className="swiper-container slider-min items">
                        <div className="swiper-wrapper">
                            {/* Single Slide */}
                            {this.state.data.map((item, idx) => {
                                return (
                                    <div key={`td_${idx}`} className="swiper-slide item">
                                        {/* Team Card */}
                                        <div className="card team-card text-center">
                                        <a className="team-photo d-inline-block" href={this.getSocialData(item.name)}>
                                            <img className="mx-auto" src={item.img} alt="" />
                                        </a>
                                        {/* Team Content */}
                                        <div className="team-content mt-3">
                                            <a href="/">
                                            <h4 className="mb-0">{item.name}</h4>
                                            </a>
                                            <span className="d-inline-block mt-2 mb-3">{item.designation}</span>
                                            
                                        </div>
                                        </div>
                                    </div>
                                )
                            })}
                        </div>
                        <div className="swiper-pagination" />
                    </div>
                </div>
            </div>
        </section>
    );
}


}


export default Team;