import { useNavigate } from "react-router";
import useAuth from "../components/Service/useAuth"


function ProtectedRoutes({children}) {
    
    const {auth} = useAuth()
    const navigate = useNavigate()
    debugger
    if(auth){
        return children;
    }
    else{
        window.location.href = '/admin/login'
    }
    return children
}

export default ProtectedRoutes