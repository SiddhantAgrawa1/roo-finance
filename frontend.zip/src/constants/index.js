// Address of the Whitelist Contract deployed already
const REACT_APP_CONTRACT_ADDRESS = process.env.REACT_APP_CONTRACT_ADDRESS;

module.exports = { REACT_APP_CONTRACT_ADDRESS };