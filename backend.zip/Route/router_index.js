const express = require('express');
const router = express.Router();
const Project_Controller = require('../controller/projects_controller')
const multer = require('multer')
// const upload = multer({dest:'uploads/'})
const auth = require('../middleware/auth')
const path = require('path')
router.use('/Images',express.static('Images'))

const storage = multer.diskStorage({
    destination : (req,file,cb) => {
        cb(null,'Images')
    },
    filename : (req,file,cb) => {
        console.log(file)
        cb(null,Date.now() + path.extname(file.originalname))
    }
})

const upload = multer({storage : storage})

// Admin
router.route('/admin/projects').post(auth,Project_Controller.getAllProjects)
router.route('/admin/updateProject/:id').put(upload.single('image'),Project_Controller.updateProject)
router.route('/project/:id').get(Project_Controller.getProject)
router.route('/admin/form').post(upload.single('image'),Project_Controller.addProject)
// router.route('/admin/upload').post(upload.single('image'),Project_Controller.uploadImage)
// router.route('/admin/validation').post(auth,Project_Controller.VerifyAdmin)
router.route('/admin/contractAddress').post(Project_Controller.addContract)
router.route('/admin/auth').post(auth, Project_Controller.verifyAdmin)
router.route('/admin/deleteProject').post(auth, Project_Controller.deleteProject)
router.route('/admin/addAmount').post(Project_Controller.addAmount)

// router.post('/ad')

// User
router.route('/projects').get(Project_Controller.getAllProjectsUser)
router.route('/projects/ended').get(Project_Controller.getAllEndedProjects)
router.route('/projects/upcoming').get(Project_Controller.getAllUpcomingProjects)
router.route('/projects/ongoing').get(Project_Controller.getAllOngoingProjects)
router.route('/projects/notended').get(Project_Controller.getAllProjectNotEnded)


module.exports = router;