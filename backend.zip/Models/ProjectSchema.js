const mongoose = require('mongoose');

const ProjectSchema = new mongoose.Schema({
    Name_Of_Project : {
        type : String,
        unique : true
    },
    Amount_of_supply : {
        type : Number
    },
    IPFS_information : {
        type : String,
    },
    Price_of_collection : {
        type : Number
    },
    Token_symbol : {
        type : String,
    },
    Limit_per_NFT : {
        type : Number
    },
    WL_List : {
        type : Array,
    },
    imgUrl : {
        type : String,
        default : ""
    },
    Project_Summary : {
        type : String,
    },
    Video : {
        type : String,
    },
    Project_Overview : {
        type : String,
    },
    // Distribution : {
    //     type : String,
    // },
    WL_Amount : {
        type : Number
    },
    Roadmap_Summary : {
        type : String,
    },
    Discord_Link : {
        type : String,
    },
    Twitter_Link : {
        type : String,
    },
    Telegram_Link : {
        type : String,
    },
    Website : {
        type : String,
    },
    Date_of_Launch : {
        type : Number,
    },
    Contract_Address : {
        type : String,
        default : ""
    },
    Project_Owner : {
        type : String,
        default : "" 
    },
    Token_Name : {
        type : String,
        default : ""
    },
    createdAt:{
        type : Number,
    },
    Duration : {
        type : Number,
        default : 1
    },
    deleteFlag : {
        type : Boolean,
        default : 0
    },
    minted : {
        type : Number,
        default : 0
    }
})


const adminSchema = new mongoose.Schema({
    username : {
        type : String,
        default : "",
        unique : true
    },
    walletAddress : {
        type : String,
        default : "",
        unique : true
    }
   
})

const Projects = new mongoose.model('projects',ProjectSchema)
const Admin = new mongoose.model('admin',adminSchema)

module.exports = { Projects, Admin }