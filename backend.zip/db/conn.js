const mongoose = require('mongoose')
// const db = 'mongodb://127.0.0.1:27017/admin'
const db = 'mongodb+srv://user:user123@cluster0.ary9rz9.mongodb.net/roo-finance?retryWrites=true&w=majority'
mongoose.connect(process.env.DB)
.then(() => {
    console.log("Database connected successfully");
})    
.catch((err) => {   
    console.log("Error",err);
})