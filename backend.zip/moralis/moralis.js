const Moralis = require('moralis')
const { EvmChain } = require("@moralisweb3/evm-utils")
const Contract_Factory_ABI = require('./abi.json')

const moralisfn = async (tag, description, contractAddress) => {
    try {
        Moralis.default.start({
            apiKey: "t7574fu2HGiBSW8Hy51cSJ6n4ENt6qbGiJYfm8acLt7JDZRItukRP7n2STI2z2VK",
        });
    
        const stream = {
            chains: [EvmChain.CRONOS],// list of blockchains to monitor
            description: description, // your description
            tag: tag, // give it a tag
            abi: Contract_Factory_ABI,
            includeContractLogs: true,
            allAddresses: false,
            topic0: ["Transfer(address,address,uint256)"], // topic of the event
            webhookUrl: "https://cronos.tools/api/admin/addAmount", // webhook url to receive events,
        };
        const newStream = await Moralis.default.Streams.add(stream);
        const { id } = newStream.toJSON(); // { id: 'YOUR_STREAM_ID', ...newStream }
        // console.log("Stream id : ",id)

        // Add bobs address to the stream
        await Moralis.default.Streams.addAddress({ id, address: contractAddress });
    
    
    } catch (error) {
        console.log("Error : ",error)
    }
    

}

module.exports = {moralisfn}
