const mongoose = require("mongoose");
const { Admin } = require("../Models/ProjectSchema");
const { verifyMessage } = require('@ambire/signature-validator')
const ethers = require('ethers');
const provider = new ethers.providers.JsonRpcProvider('https://bsc-testnet.public.blastapi.io')

const auth = async (req, res, next) => {
  try {
    const { username, address, signature } = req.body;
    const isValidAdmin = await Admin.findOne({username : username, walletAddress : address})
    if(isValidAdmin === null) res.status(401).send({status : 401, message:"Invalid credentials!"})
    const isValidSign = await verifySignatureLogin(address, signature);
    
    if(isValidSign === true)
        next()
    else 
        res.status(401).send({status : 401, message:"Authentication failed"})
  } catch (error) {
    res.status(401).send({ status: 401, message:"Authentication failed" });
  }
};


const verifySignatureLogin = async (address, signature) => {
  return await validateTheSignature(address, signature);
};

async function validateTheSignature(address, signature) {
  let messageString = `Welcome to roo-finance ${address} ${new Date()
    .toISOString()
    .slice(0, 10)}`;
  let x = await verifySignature01(messageString, signature, address);
  return x;
}

async function verifySignature01(message, signature, address) {
  const isValidSig = await verifyMessage({
    signer: address,
    message: message,
    signature: signature,
    // this is needed so that smart contract signatures can be verified
    provider,
  });
  // console.log('is the sig valid: ', isValidSig)
  return isValidSig;
}

module.exports = auth;
