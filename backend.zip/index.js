const express = require('express')
const bodyParser = require('body-parser')
const mongoose = require('mongoose')
const cors = require('cors');
require('dotenv').config()
mongoose.set('strictQuery', true);
const app = express()
const corsOrigin = {
    origin: "*",
}

app.use(cors(corsOrigin))
app.use(bodyParser.json())
require('./db/conn')
const path = require('path')
var util = require('util');
var encoder = new util.TextEncoder('utf-8');

const routerFile = require('./Route/router_index')

app.use(express.static(path.join(__dirname, './frontend/build')))

app.use('/', routerFile)

const port = process.env.PORT || 8000

// const cors = require('cors');
// app.use(cors({
//     origin: 'https://www.section.io'
// }));

app.listen(port, () => {
    console.log("server successfully started at 8000 port")
})

// module.exports = app;