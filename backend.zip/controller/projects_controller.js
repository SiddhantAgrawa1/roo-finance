const { verify } = require("jsonwebtoken");
const mongoose = require("mongoose");
const { Projects, Admin } = require("../Models/ProjectSchema");
const { moralisfn } = require("../moralis/moralis");

exports.getAllProjects = async (req, res) => {
  try {
    const data = await Projects.find({});
    res.status(200).send({ data: data, status: 200 });
  } catch (error) {
    res.status(500).send({ data: "Data not found", status: 500 });
  }
};

exports.getProject = async (req, res) => {
  let id = String(req.params.id);
  id = id.replace(/-/g, " ")
  try {
    const data = await Projects.findOne({ Name_Of_Project: id });
    res.status(200).send({ data: data, status: 200 });
  } catch (error) {
    res.status(500).send({ data: "Data not found", status: 500 });
  }
};

// exports.addProject = async (req, res) => {
//   try {
//     const {contents} = req.body
//     // const admin = new Projects(contents);
//     // const resp = await admin.save();
//     res.status(200).send({ status: 200 });
//   } catch (error) {
//     res.status(500).send({ status: 500 });
//   }
// };

exports.addProject = async (req, res) => {
  try {
    const imgUrl = req.file.path || null;
    let contents = JSON.parse(req.body.data);
    contents["imgUrl"] = imgUrl;
    const found = await Projects.find({
      Name_Of_Project: contents.Name_Of_Project,
    });
    if (found.length > 0) {
      return res.status(403).json({ message: "project name already exists" });
    } else {
      const admin = new Projects(contents);
      const resp = await admin.save();
      res.status(200).json({ message: "project added successfully" });
    }
  } catch (error) {
    res.status(500).json({ message: "internal sever error" });
  }
};

exports.updateProject = async (req, res) => {
  try {
    let contents = JSON.parse(req.body.data);
    const imgUrl = req.file ? req.file.path : contents.imgUrl;
    contents["imgUrl"] = imgUrl;

    const updateResult = await Projects.updateMany(
      { _id: req.params.id },
      {
        Name_Of_Project: contents.Name_Of_Project,
        Amount_of_supply: contents.Amount_of_supply,
        IPFS_information: contents.IPFS_information,
        Price_of_collection: contents.Price_of_collection,
        Token_symbol: contents.Token_symbol,
        Limit_per_NFT: contents.Limit_per_NFT,
        WL_List: contents.WL_List,
        imgUrl: contents.imgUrl,
        Project_Summary: contents.Project_Summary,
        Video: contents.Video,
        Project_Overview: contents.Project_Overview,
        Distribution: contents.Distribution,
        Roadmap_Summary: contents.Roadmap_Summary,
        Discord_Link: contents.Discord_Link,
        Twitter_Link: contents.Twitter_Link,
        Telegram_Link: contents.Telegram_Link,
        Website: contents.Website,
        Date_of_Launch: contents.Date_of_Launch,
        Contract_Address: contents.Contract_Address,
        Project_Owner: contents.Project_Owner,
        Token_Name: contents.Token_Name,
        Duration: contents.Duration,
      }
    );

    return res.status(200).json({ message: "project updated success" });
  } catch (error) {
    res.status(500).json({ message: "internal sever error" });
  }
};

exports.addContract = async (req, res) => {
  try {
    const resp = req.body;
    const contract = resp.address.toLowerCase();
    const data = await Projects.updateOne(
      { Name_Of_Project: resp.projectName },
      { $set: { Contract_Address: contract } }
    );
    if (data.matchCount == 0)
      return res.status(404).json({ message: "project not found" });
    else {
      await moralisfn(resp.Token_Name, resp.projectName, resp.address);
      return res.status(200).json({ message: "contract added successfully" });
    }
  } catch (err) {
    return res.status(500).send({ message: "internal server error" });
  }
};

exports.verifyAdmin = (req, res) => {
  console.log("verify");
  res.status(200).send({ status: 200 });
};

exports.getAllProjectsUser = async (req, res) => {
  try {
    const perPage = 4; // number of projects per page
    const page = req.query.page || 1; // current page number
    const start = (page - 1) * perPage; // starting index of projects to fetch
    const totalProjects = await Projects.find({
      Contract_Address: { $not: { $eq: "" } },
      deleteFlag: 0,
    }).countDocuments(); // total number of projects
    const projects = await Projects.find({
      Contract_Address: { $not: { $eq: "" } },
      deleteFlag: 0,
    })
      .sort({ $natural: -1 })
      .skip(start)
      .limit(perPage); // fetch projects
    const totalPages = Math.ceil(totalProjects / perPage); // total number of pages
    const currentPage = parseInt(page); // current page number

    return res.status(200).json({
      data: projects,
      perPage: perPage,
      totalItems: totalProjects,
      currentPage: currentPage,
      totalPages: totalPages,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

exports.getAllEndedProjects = async (req, res) => {
  try {
    const perPage = 4; // number of projects per page
    const page = req.query.page || 1; // current page number
    const start = (page - 1) * perPage; // starting index of projects to fetch
    const totalProjects = await Projects.find({
      Contract_Address: { $not: { $eq: "" } },
      $expr: {
        $eq: ["$minted", "$Amount_of_supply"],
      },
      deleteFlag: 0,
    }).countDocuments(); // total number of projects
    
    const projects = await Projects.find({
      Contract_Address: { $not: { $eq: "" } },
      $expr: {
        $eq: ["$minted", "$Amount_of_supply"],
      },
      deleteFlag: 0,
    })
      .sort({ $natural: -1 })
      .skip(start)
      .limit(perPage); // fetch projects
    // projects = projects.filter((item) => item.Contract_Address !== "" && new Date(item.Date_of_Launch) <= new Date() );
    // projects = projects.filter((item) => item.minted === item.Amount_of_supply && item.deleteFlag != 1 )
    console.log(projects);

    const totalPages = Math.ceil(totalProjects / perPage); // total number of pages
    const currentPage = parseInt(page); // current page number

    return res.status(200).json({
      data: projects,
      perPage: perPage,
      totalItems: totalProjects,
      currentPage: currentPage,
      totalPages: totalPages,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

exports.getAllUpcomingProjects = async (req, res) => {
  try {
    const CurrentDate = new Date().getTime() / 1000;
    const perPage = 4; // number of projects per page
    const page = req.query.page || 1; // current page number
    const start = (page - 1) * perPage; // starting index of projects to fetch
      const totalProjects = await Projects.find({
        Contract_Address: { $not: { $eq: "" } },
        Date_of_Launch: { $gt: CurrentDate },
      }).countDocuments(); // total number of projects
    
    // console.log(totalProjects)
    const projects = await Projects.find({
      Contract_Address: { $not: { $eq: "" } },
      Date_of_Launch: { $gt: CurrentDate },
    })
      .sort({ $natural: -1 })
      .skip(start)
      .limit(perPage); // fetch projects
    // projects = projects.filter((item) => item.Contract_Address !== "" && new Date(item.Date_of_Launch) <= new Date() );
    // projects = projects.filter((item) => item.minted === item.Amount_of_supply && item.deleteFlag != 1 )
    // console.log(projects);

    const totalPages = Math.ceil(totalProjects / perPage); // total number of pages
    const currentPage = parseInt(page); // current page number

    return res.status(200).json({
      data: projects,
      perPage: perPage,
      totalItems: totalProjects,
      currentPage: currentPage,
      totalPages: totalPages,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

exports.getAllOngoingProjects = async (req, res) => {
  try {
    const CurrentDate = new Date().getTime() / 1000;
    console.log(CurrentDate)
    const perPage = 4; // number of projects per page
    const page = req.query.page || 1; // current page number
    const start = (page - 1) * perPage; // starting index of projects to fetch

    const totalProjects = await Projects.countDocuments({
      Contract_Address: { $ne: "" },
      $expr: { $lt: ["$minted", "$Amount_of_supply"] },
      Date_of_Launch: { $lt: CurrentDate },
      deleteFlag: 0,
    }); // total number of projects
    
    const projects = await Projects.find({
      Contract_Address: { $ne: "" },
      $expr: { $lt: ["$minted", "$Amount_of_supply"] },
      Date_of_Launch: { $lt: CurrentDate },
      deleteFlag: 0,
    })
      .sort({ $natural: -1 })
      .skip(start)
      .limit(perPage); // fetch projects

    const totalPages = Math.ceil(totalProjects / perPage); // total number of pages
    const currentPage = parseInt(page); // current page number

    return res.status(200).json({
      data: projects,
      perPage: perPage,
      totalItems: totalProjects,
      currentPage: currentPage,
      totalPages: totalPages,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};




exports.getAllProjectNotEnded = async (req, res) => {
  try {
    let perPage = 7
    const projects = await Projects.find({
      Contract_Address: { $not: { $eq: "" } },
      $expr: {
        $ne: ["$minted", "$Amount_of_supply"],
      },
      deleteFlag: 0,
    })
      .sort({ $natural: -1 })
      .limit(perPage); // fetch projects

    return res.status(200).json({
      data: projects
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

exports.deleteProject = async (req, res) => {
  try {
    const _id = req.body._id;
    const data = await Projects.updateMany(
      { _id: _id },
      { $set: { deleteFlag: 1 } }
    );
    console.log("delete Project ; ", data);
    if (data.modifiedCount == 0)
      return res.status(404).json({ message: "project not found" });
    else
      return res.status(200).json({ message: "Project delete successfully" });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Something went wrong", error: error });
  }
};

exports.addAmount = async (req, res) => {
  try {
    // console.log(req.body)
    const status = req.body.confirmed;
    // if condition is removed because it takes to long for confirmation
    // if (status) {
      let contractAddress = req.body.nftTransfers[0].contract;
      const Found = await Projects.findOne({
        Contract_Address: contractAddress,
      });
      // console.log(Found)
      if (Found !== null) {
        let amount = req.body.nftTransfers[req.body.nftTransfers.length - 1].tokenId;
        // const prevAmount = Found.minted;
        let newAmount = parseInt(amount);
        // console.log(newAmount)
        const updateStatus = await Projects.updateOne(
          { Contract_Address: contractAddress },
          { $set: { minted: newAmount } }
        );
        // console.log(updateStatus)
        if (updateStatus.modifiedCount === 1) {
          return res
            .status(200)
            .send({ message: "Amount updated successfully!" });
        } else {
          return res.status(500).send({ message: "Contract address not found!" });
        }
      }
      return res.status(200).send({ message: "Contract address not found!" });
    // }
    // return res.status(200).send();
  } catch (error) {
    console.log(error);
    return res.status(200).send({message : error});
  }
};
